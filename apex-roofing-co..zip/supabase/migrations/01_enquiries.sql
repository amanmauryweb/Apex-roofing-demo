-- ============================================================
-- Apex Roofing Co. - Supabase PostgreSQL Schema Migration
-- Migration: 01_enquiries.sql
-- ============================================================

-- 1. Create enquiries table
CREATE TABLE IF NOT EXISTS public.enquiries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    property_type TEXT NOT NULL CHECK (property_type IN ('Residential', 'Commercial')),
    service_needed TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'reviewed', 'scheduled', 'archived')),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Performance indexes for dashboard filtering and date sorting
CREATE INDEX IF NOT EXISTS idx_enquiries_created_at ON public.enquiries (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_enquiries_status ON public.enquiries (status);
CREATE INDEX IF NOT EXISTS idx_enquiries_property_type ON public.enquiries (property_type);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policy: Allow anonymous and public visitors to INSERT new estimate requests
-- Visitors can write, but cannot read or update existing enquiries
CREATE POLICY "Public anonymous visitors can submit enquiries"
ON public.enquiries
FOR INSERT
TO public
WITH CHECK (
    char_length(full_name) >= 2 AND
    char_length(phone) >= 10 AND
    char_length(email) >= 5 AND
    char_length(message) >= 10
);

-- 5. RLS Policy: Restrict reading enquiries to authenticated staff only
-- Anonymous users CANNOT query or view other users' submissions
CREATE POLICY "Only authenticated managers can view enquiries"
ON public.enquiries
FOR SELECT
TO authenticated
USING (true);

-- 6. RLS Policy: Restrict updates/deletes to authenticated staff only
CREATE POLICY "Only authenticated managers can update enquiries"
ON public.enquiries
FOR UPDATE
TO authenticated
USING (true);
