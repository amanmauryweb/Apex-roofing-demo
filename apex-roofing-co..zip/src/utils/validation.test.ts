import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEmail, validatePhone, validateQuoteForm, formatPhoneNumber } from './validation';

test('validateEmail validates RFC compliant email addresses', () => {
  assert.equal(validateEmail('client@apexroofing.com'), true);
  assert.equal(validateEmail('test.user+tag@domain.co.uk'), true);
  assert.equal(validateEmail('invalid-email'), false);
  assert.equal(validateEmail('user@domain'), false);
  assert.equal(validateEmail(''), false);
});

test('validatePhone validates 10+ digit phone numbers', () => {
  assert.equal(validatePhone('(214) 555-0192'), true);
  assert.equal(validatePhone('+1 972 555 4321'), true);
  assert.equal(validatePhone('2145550192'), true);
  assert.equal(validatePhone('12345'), false);
  assert.equal(validatePhone('abc-def-ghij'), false);
});

test('formatPhoneNumber formats raw digits into friendly US format', () => {
  assert.equal(formatPhoneNumber('2145550199'), '(214) 555-0199');
  assert.equal(formatPhoneNumber('214'), '214');
});

test('validateQuoteForm catches missing fields and permits valid submission', () => {
  const invalid = validateQuoteForm({
    fullName: '',
    phone: '',
    email: 'bad',
    propertyType: undefined,
    serviceNeeded: '',
    message: 'short'
  });
  assert.equal(invalid.isValid, false);
  assert.ok(invalid.errors.fullName);
  assert.ok(invalid.errors.phone);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.message);

  const valid = validateQuoteForm({
    fullName: 'Eleanor Vance',
    phone: '(214) 555-8392',
    email: 'eleanor@example.com',
    propertyType: 'Residential',
    serviceNeeded: 'Roof Replacement',
    message: 'Looking for standing seam metal replacement on our Highland Park residence.'
  });
  assert.equal(valid.isValid, true);
  assert.equal(Object.keys(valid.errors).length, 0);
});
