/**
 * Form validation utilities for Quote Enquiry submissions.
 */

export interface QuoteFormData {
  fullName: string;
  phone: string;
  email: string;
  propertyType: 'Residential' | 'Commercial';
  serviceNeeded: string;
  message: string;
}

export interface ValidationErrors {
  fullName?: string;
  phone?: string;
  email?: string;
  propertyType?: string;
  serviceNeeded?: string;
  message?: string;
}

export function validateEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  return re.test(email.trim());
}

export function validatePhone(phone: string): boolean {
  if (!phone || typeof phone !== 'string') return false;
  // Accepts standard North American formats: (123) 456-7890, 123-456-7890, 1234567890, +1 123 456 7890
  const cleaned = phone.replace(/[\s\-\(\)\.\+]/g, '');
  return cleaned.length >= 10 && cleaned.length <= 15 && /^\d+$/.test(cleaned);
}

export function validateQuoteForm(data: Partial<QuoteFormData>): { isValid: boolean; errors: ValidationErrors } {
  const errors: ValidationErrors = {};

  if (!data.fullName || data.fullName.trim().length < 2) {
    errors.fullName = "Please enter your full legal or company name.";
  }

  if (!data.phone || !validatePhone(data.phone)) {
    errors.phone = "Please enter a valid phone number (minimum 10 digits).";
  }

  if (!data.email || !validateEmail(data.email)) {
    errors.email = "Please enter a valid email address.";
  }

  if (!data.propertyType || !['Residential', 'Commercial'].includes(data.propertyType)) {
    errors.propertyType = "Please select either Residential or Commercial property.";
  }

  if (!data.serviceNeeded || data.serviceNeeded.trim().length === 0) {
    errors.serviceNeeded = "Please select the roofing service needed.";
  }

  if (!data.message || data.message.trim().length < 10) {
    errors.message = "Please include a brief description of your roofing project (min 10 characters).";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function formatPhoneNumber(val: string): string {
  const numbers = val.replace(/\D/g, '');
  if (numbers.length <= 3) return numbers;
  if (numbers.length <= 6) return `(${numbers.slice(0, 3)}) ${numbers.slice(3)}`;
  return `(${numbers.slice(0, 3)}) ${numbers.slice(3, 6)}-${numbers.slice(6, 10)}`;
}
