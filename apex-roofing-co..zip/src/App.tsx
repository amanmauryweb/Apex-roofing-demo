import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/navigation/Navbar';
import { Footer } from './components/navigation/Footer';
import { FloatingCTA } from './components/navigation/FloatingCTA';
import { QuoteModal } from './components/forms/QuoteModal';
import { ImageLightbox } from './components/gallery/ImageLightbox';
import { EnquiriesDrawer } from './components/common/EnquiriesDrawer';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Services } from './pages/Services';
import { Projects } from './pages/Projects';
import { Reviews } from './pages/Reviews';
import { Contact } from './pages/Contact';
import { PROJECTS_DATA } from './data/projects';

// Helper component to scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<string | undefined>(undefined);
  const [lightboxProjectIndex, setLightboxProjectIndex] = useState<number | null>(null);
  const [isEnquiriesDrawerOpen, setIsEnquiriesDrawerOpen] = useState(false);

  const handleOpenQuoteModal = (serviceName?: string) => {
    setSelectedServiceForModal(serviceName);
    setIsQuoteModalOpen(true);
  };

  const handleCloseQuoteModal = () => {
    setIsQuoteModalOpen(false);
    setSelectedServiceForModal(undefined);
  };

  const handleOpenLightbox = (index: number) => {
    setLightboxProjectIndex(index);
  };

  const handleCloseLightbox = () => {
    setLightboxProjectIndex(null);
  };

  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-[#17191C] text-white flex flex-col justify-between selection:bg-[#F97316] selection:text-white">
        {/* Navigation Bar */}
        <Navbar
          onOpenQuoteModal={() => handleOpenQuoteModal()}
          onOpenEnquiriesDrawer={() => setIsEnquiriesDrawerOpen(true)}
        />

        {/* Main Routed Content */}
        <main className="flex-1">
          <Routes>
            <Route
              path="/"
              element={
                <Home
                  onOpenQuoteModal={handleOpenQuoteModal}
                  onSelectProjectForLightbox={handleOpenLightbox}
                />
              }
            />
            <Route
              path="/about"
              element={<About onOpenQuoteModal={() => handleOpenQuoteModal()} />}
            />
            <Route
              path="/services"
              element={<Services onOpenQuoteModal={handleOpenQuoteModal} />}
            />
            <Route
              path="/projects"
              element={
                <Projects
                  onSelectProjectForLightbox={handleOpenLightbox}
                  onOpenQuoteModal={handleOpenQuoteModal}
                />
              }
            />
            <Route
              path="/reviews"
              element={<Reviews onOpenQuoteModal={() => handleOpenQuoteModal()} />}
            />
            <Route
              path="/contact"
              element={<Contact onOpenEnquiriesDrawer={() => setIsEnquiriesDrawerOpen(true)} />}
            />
            {/* Fallback route */}
            <Route
              path="*"
              element={
                <div className="pt-40 pb-28 text-center max-w-xl mx-auto px-6 space-y-6">
                  <h1 className="font-space text-4xl font-bold">Page Not Found</h1>
                  <p className="text-[#A5A9AE] text-sm">
                    The requested architectural link has been moved or does not exist.
                  </p>
                  <a
                    href="/"
                    className="inline-block bg-[#F97316] hover:bg-[#EA580C] text-white px-6 py-3 rounded-sm text-xs uppercase font-bold tracking-wider"
                  >
                    Return to Home
                  </a>
                </div>
              }
            />
          </Routes>
        </main>

        {/* Footer */}
        <Footer onOpenQuoteModal={() => handleOpenQuoteModal()} />

        {/* Global Floating Estimate CTA */}
        <FloatingCTA onOpenQuoteModal={() => handleOpenQuoteModal()} />

        {/* Global Interactive Quote Request Modal */}
        <QuoteModal
          isOpen={isQuoteModalOpen}
          onClose={handleCloseQuoteModal}
          defaultService={selectedServiceForModal}
        />

        {/* Architectural Image Lightbox */}
        <ImageLightbox
          projects={PROJECTS_DATA}
          currentIndex={lightboxProjectIndex}
          onClose={handleCloseLightbox}
          onNavigate={(newIdx) => setLightboxProjectIndex(newIdx)}
          onOpenQuoteModal={() => {
            handleCloseLightbox();
            handleOpenQuoteModal();
          }}
        />

        {/* Enquiries Inspector Drawer */}
        <EnquiriesDrawer
          isOpen={isEnquiriesDrawerOpen}
          onClose={() => setIsEnquiriesDrawerOpen(false)}
          onOpenQuoteModal={() => {
            setIsEnquiriesDrawerOpen(false);
            handleOpenQuoteModal();
          }}
        />
      </div>
    </Router>
  );
}
