import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Compass, Eye, Hammer, Sparkles, Building2, CheckCircle2 } from 'lucide-react';
import { BUSINESS_CONFIG } from '../config/business';

interface AboutProps {
  onOpenQuoteModal: () => void;
}

export const About: React.FC<AboutProps> = ({ onOpenQuoteModal }) => {
  return (
    <div className="pt-28 pb-20 font-inter bg-[#17191C] text-white">
      {/* 1. Editorial Hero */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="max-w-3xl space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            About Apex Roofing Co.
          </span>
          <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            An Architectural Perspective on Roofing.
          </h1>
          <p className="text-lg text-[#A5A9AE] font-light leading-relaxed">
            Founded on the principle that roofing should never be treated as an afterthought or a generic utility trade. We treat every roof plane as an architectural crown engineered to withstand the rigorous North Texas climate.
          </p>
        </div>
      </section>

      {/* Hero Image Showcase */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-20">
        <div className="relative aspect-[21/9] rounded-sm overflow-hidden border border-white/10 shadow-2xl">
          <img
            src="/src/assets/images/hero_architectural_roof_1793626321423.jpg"
            alt="Apex Roofing Co architectural craftsmanship showcase"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
          <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-[#A5A9AE]">
            <span className="font-space text-white text-sm font-bold">Highland Park Demonstration Commission</span>
            <span>24-Gauge Standing Seam & Class 4 Laminated Shingle Assembly</span>
          </div>
        </div>
      </section>

      {/* 2. Brand Introduction & Philosophy */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-16 border-t border-white/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-4 space-y-3">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Core Ethos
            </span>
            <h2 className="font-space text-3xl font-bold text-white">
              The Intersection of Form and Climate Armor.
            </h2>
          </div>

          <div className="lg:col-span-8 space-y-6 text-[#A5A9AE] text-sm md:text-base leading-relaxed font-light">
            <p>
              In Dallas and North Texas, roofs face an unforgiving spectrum of environmental stresses: blistering summer UV index cycles exceeding 100°F, sudden springtime hail impact, torrential downpours, and violent straight-line wind events.
            </p>
            <p>
              Under these severe dynamics, standard contractor shortcuts—such as re-using degraded valley flashing or skipping high-temperature synthetic underlayments—inevitably cause hidden subterranean moisture damage. Apex was established with a singular standard: build with uncompromising structural integrity and architectural refinement.
            </p>
            <div className="p-4 bg-[#24282D] border border-white/10 rounded-sm text-xs text-[#A5A9AE]">
              <span className="text-white font-semibold block mb-1">Portfolio Transparency Notice:</span>
              {BUSINESS_CONFIG.disclaimer}
            </div>
          </div>
        </div>
      </section>

      {/* 4. Mission and Values */}
      <section className="py-20 bg-[#24282D] border-y border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="max-w-xl mb-16 space-y-3">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Guiding Principles
            </span>
            <h2 className="font-space text-3xl sm:text-4xl font-bold text-white">
              Our Mission & Four Values.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-[#17191C] p-6 rounded-sm border border-white/10 space-y-3">
              <Eye className="w-6 h-6 text-[#F97316]" />
              <h3 className="font-space text-lg font-bold text-white">01. Uncompromising Precision</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Zero tolerance for misaligned standing seam panels, undersized underlayment laps, or sloppy caulking patches.
              </p>
            </div>

            <div className="bg-[#17191C] p-6 rounded-sm border border-white/10 space-y-3">
              <Hammer className="w-6 h-6 text-[#F97316]" />
              <h3 className="font-space text-lg font-bold text-white">02. Honest Diagnostics</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                We never recommend a full replacement when a precision localized repair or underlayment restoration will safeguard the property.
              </p>
            </div>

            <div className="bg-[#17191C] p-6 rounded-sm border border-white/10 space-y-3">
              <Compass className="w-6 h-6 text-[#F97316]" />
              <h3 className="font-space text-lg font-bold text-white">03. Material Integrity</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                We specify only premier architectural-grade materials: Kynar 500 metal finishes, Class 4 impact shingles, and heavy single-ply membranes.
              </p>
            </div>

            <div className="bg-[#17191C] p-6 rounded-sm border border-white/10 space-y-3">
              <ShieldCheck className="w-6 h-6 text-[#F97316]" />
              <h3 className="font-space text-lg font-bold text-white">04. Respect for Property</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Comprehensive ground tarp protection, magnetic nail sweeps thrice daily, and minimal operational disruption.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Residential & Commercial Dual Expertise */}
      <section className="py-20 max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Residential Card */}
          <div className="bg-[#24282D] border border-white/10 rounded-sm p-8 space-y-6">
            <div className="aspect-video rounded-sm overflow-hidden border border-white/10">
              <img
                src="/src/assets/images/project_residential_modern_1793626323900.jpg"
                alt="Residential roofing craft"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase text-[#F97316]">Division 01</span>
              <h3 className="font-space text-2xl font-bold text-white">Residential Architecture</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Specializing in steep-slope residential roofs, custom architectural metal gables, composite slate, and cedar shake transitions tailored to luxury residences in Dallas, Highland Park, Preston Hollow, and Southlake.
              </p>
              <ul className="text-xs text-white/80 space-y-2 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Standing seam hidden-fastener metal profiles</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Impact-resistant Class 4 hail-rated shingles</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Custom soldered copper and zinc flashing pans</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Commercial Card */}
          <div className="bg-[#24282D] border border-white/10 rounded-sm p-8 space-y-6">
            <div className="aspect-video rounded-sm overflow-hidden border border-white/10">
              <img
                src="/src/assets/images/project_commercial_tpo_1793626324115.jpg"
                alt="Commercial roofing craft"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase text-[#F97316]">Division 02</span>
              <h3 className="font-space text-2xl font-bold text-white">Commercial Flat & Low-Slope</h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Engineering high-solar-reflectance TPO, chemical-resistant PVC, and modified bitumen assemblies for corporate campuses, retail developments, logistics facilities, and multi-family communities.
              </p>
              <ul className="text-xs text-white/80 space-y-2 pt-2">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Energy Star & CRRC compliant 60–80 mil white TPO</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Tapered ISO insulation eliminating ponding water</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#F97316]" />
                  <span>Phased staging avoiding tenant disruption</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Call to Action */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="bg-gradient-to-r from-[#24282D] to-[#1D2024] border border-white/10 rounded-sm p-8 lg:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Begin Your Project
            </span>
            <h3 className="font-space text-2xl sm:text-3xl font-bold text-white">
              Ready to Upgrade Your Roofing Shield?
            </h3>
            <p className="text-xs text-[#A5A9AE]">
              Contact our Dallas estimating team to discuss your project specifications and schedule a comprehensive forensic site audit.
            </p>
          </div>

          <button
            onClick={onOpenQuoteModal}
            type="button"
            className="bg-[#F97316] hover:bg-[#EA580C] text-white px-8 py-4 rounded-sm text-xs font-bold uppercase tracking-widest whitespace-nowrap shrink-0 transition-colors shadow-xl shadow-[#F97316]/20"
          >
            Request Free Estimate
          </button>
        </div>
      </section>
    </div>
  );
};
