import React from 'react';
import { QuoteForm } from '../components/forms/QuoteForm';
import { ServiceAreaMap } from '../components/common/ServiceAreaMap';
import { FAQAccordion } from '../components/common/FAQAccordion';
import { FAQ_DATA } from '../data/faq';
import { BUSINESS_CONFIG } from '../config/business';
import { Phone, Mail, MapPin, Clock, ShieldCheck, AlertCircle } from 'lucide-react';

interface ContactProps {
  onOpenEnquiriesDrawer: () => void;
}

export const Contact: React.FC<ContactProps> = ({ onOpenEnquiriesDrawer }) => {
  return (
    <div className="pt-28 pb-20 font-inter bg-[#17191C] text-white">
      {/* 1. Page Introduction Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="max-w-3xl space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            Project Inquiries & Diagnostics
          </span>
          <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Let's Discuss Your Roof.
          </h1>
          <p className="text-base sm:text-lg text-[#A5A9AE] font-light leading-relaxed">
            Whether planning an architectural replacement for an estate in Highland Park or coordinating commercial single-ply installation across North Texas, our team provides timely, itemized project estimates.
          </p>
        </div>
      </section>

      {/* Main Split: Contact Information Placeholders & Interactive Quote Request Form */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Business Placeholders & Office Hours */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
                Direct Contact
              </span>
              <h2 className="font-space text-2xl sm:text-3xl font-bold text-white">
                Dallas Metro Headquarters
              </h2>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                All business contact parameters shown are clearly identifiable demonstration placeholders.
              </p>
            </div>

            {/* Placeholders Card */}
            <div className="bg-[#24282D] border border-white/10 rounded-sm p-6 space-y-6">
              {/* Telephone */}
              <div className="flex items-start gap-4 pb-4 border-b border-white/5">
                <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase text-[#A5A9AE] block">
                    Phone (Editable Placeholder)
                  </span>
                  <span className="text-lg font-space font-bold text-white font-mono">
                    {BUSINESS_CONFIG.phonePlaceholder}
                  </span>
                  <span className="text-[11px] text-[#A5A9AE] block mt-0.5">
                    *Placeholder: inoperative until real credentials configured
                  </span>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-4 pb-4 border-b border-white/5">
                <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase text-[#A5A9AE] block">
                    Email (Editable Placeholder)
                  </span>
                  <span className="text-base font-space font-bold text-white">
                    {BUSINESS_CONFIG.emailPlaceholder}
                  </span>
                  <span className="text-[11px] text-[#A5A9AE] block mt-0.5">
                    Monitored during business hours
                  </span>
                </div>
              </div>

              {/* Service Area */}
              <div className="flex items-start gap-4 pb-4 border-b border-white/5">
                <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase text-[#A5A9AE] block">
                    Metro Coverage (Illustrative)
                  </span>
                  <span className="text-base font-space font-bold text-white">
                    {BUSINESS_CONFIG.location}
                  </span>
                  <span className="text-[11px] text-[#A5A9AE] block mt-0.5">
                    {BUSINESS_CONFIG.coverage}
                  </span>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div className="space-y-1 text-xs">
                  <span className="text-[10px] font-mono uppercase text-[#A5A9AE] block">
                    Operational Hours
                  </span>
                  <p className="text-white font-medium">{BUSINESS_CONFIG.hours.weekdays}</p>
                  <p className="text-[#A5A9AE]">{BUSINESS_CONFIG.hours.saturday}</p>
                  <p className="text-[#A5A9AE]">{BUSINESS_CONFIG.hours.sunday}</p>
                </div>
              </div>
            </div>

            {/* Submissions Inspector Trigger Button */}
            <div className="p-4 bg-[#17191C] border border-white/10 rounded-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Testing Quote Submissions?</span>
                <button
                  onClick={onOpenEnquiriesDrawer}
                  type="button"
                  className="px-3 py-1 bg-[#F97316] text-white text-xs uppercase tracking-wider font-bold rounded-sm"
                >
                  View Database
                </button>
              </div>
              <p className="text-[11px] text-[#A5A9AE]">
                Any estimate submitted through the form on the right is recorded and instantly visible in the Enquiries Inspector drawer.
              </p>
            </div>
          </div>

          {/* Right Column: Full Functional Quote Request Form */}
          <div className="lg:col-span-7">
            <QuoteForm />
          </div>
        </div>
      </section>

      {/* 6. Service Area Map Illustration */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-24 border-t border-white/10 pt-20">
        <ServiceAreaMap />
      </section>

      {/* 7. Contact Assistance FAQ */}
      <section className="max-w-4xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-12 space-y-3">
          <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
            Estimate Inquiries
          </span>
          <h2 className="font-space text-3xl font-bold text-white">
            What to Expect During Your Estimate
          </h2>
          <p className="text-xs text-[#A5A9AE]">
            Answers to common questions regarding timelines, inspections, and project proposals.
          </p>
        </div>

        <FAQAccordion items={FAQ_DATA.slice(0, 4)} />
      </section>
    </div>
  );
};
