import React, { useState } from 'react';
import { SERVICES_DATA, ServiceItem } from '../data/services';
import { ArrowRight, CheckCircle2, Shield, Clock, Layers, Filter } from 'lucide-react';

interface ServicesProps {
  onOpenQuoteModal: (serviceName?: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onOpenQuoteModal }) => {
  const [filterCategory, setFilterCategory] = useState<'all' | 'residential' | 'commercial'>('all');
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);

  const filteredServices = SERVICES_DATA.filter((s) => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'residential') return s.category === 'residential' || s.category === 'both';
    if (filterCategory === 'commercial') return s.category === 'commercial' || s.category === 'both';
    return true;
  });

  return (
    <div className="pt-28 pb-20 font-inter bg-[#17191C] text-white">
      {/* Services Hero Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="max-w-3xl space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            Capabilities & Disciplines
          </span>
          <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Engineered Roofing Systems.
          </h1>
          <p className="text-base sm:text-lg text-[#A5A9AE] font-light leading-relaxed">
            From precision steep-slope standing seam installations to high-capacity commercial single-ply membranes, explore our seven specialized service offerings across North Texas.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="mt-8 flex items-center gap-2 border-b border-white/10 pb-4">
          <span className="text-xs text-[#A5A9AE] mr-2 flex items-center gap-1 font-mono uppercase">
            <Filter className="w-3.5 h-3.5 text-[#F97316]" /> Filter:
          </span>
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-4 py-2 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors ${
              filterCategory === 'all'
                ? 'bg-[#F97316] text-white'
                : 'bg-[#24282D] text-[#A5A9AE] hover:text-white'
            }`}
          >
            All Services (7)
          </button>
          <button
            onClick={() => setFilterCategory('residential')}
            className={`px-4 py-2 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors ${
              filterCategory === 'residential'
                ? 'bg-[#F97316] text-white'
                : 'bg-[#24282D] text-[#A5A9AE] hover:text-white'
            }`}
          >
            Residential Focus
          </button>
          <button
            onClick={() => setFilterCategory('commercial')}
            className={`px-4 py-2 text-xs font-medium uppercase tracking-wider rounded-sm transition-colors ${
              filterCategory === 'commercial'
                ? 'bg-[#F97316] text-white'
                : 'bg-[#24282D] text-[#A5A9AE] hover:text-white'
            }`}
          >
            Commercial Focus
          </button>
        </div>
      </section>

      {/* Services List Deep-Dive */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 space-y-12">
        {filteredServices.map((service, idx) => (
          <div
            key={service.id}
            id={service.id}
            className="bg-[#24282D] border border-white/10 rounded-sm p-8 lg:p-12 transition-all hover:border-white/20 scroll-mt-28"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Header Info */}
              <div className="lg:col-span-5 space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-xl font-space font-bold text-[#F97316]">
                    {service.number}
                  </span>
                  <span className="text-[10px] uppercase font-mono tracking-wider px-2.5 py-0.5 bg-[#17191C] text-[#A5A9AE] border border-white/5 rounded">
                    {service.category} application
                  </span>
                </div>

                <h2 className="font-space text-2xl sm:text-3xl font-bold text-white leading-tight">
                  {service.title}
                </h2>

                <p className="text-xs text-[#F97316] font-mono">
                  {service.tagline}
                </p>

                <p className="text-sm text-[#A5A9AE] leading-relaxed">
                  {service.extendedOverview}
                </p>

                <div className="pt-2 space-y-2 text-xs text-[#A5A9AE]">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#F97316]" />
                    <span>Estimated Timeline: <strong className="text-white">{service.estimatedTimeline}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#F97316]" />
                    <span>Warranty: <strong className="text-white">{service.warrantyHighlight}</strong></span>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    onClick={() => onOpenQuoteModal(service.title)}
                    type="button"
                    className="inline-flex items-center gap-2 bg-[#F97316] hover:bg-[#EA580C] text-white px-6 py-3 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
                  >
                    <span>Request Estimate for {service.title}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Detailed Technical Specifications & Benefits */}
              <div className="lg:col-span-7 space-y-6 bg-[#17191C] p-6 lg:p-8 rounded-sm border border-white/5">
                <div>
                  <h4 className="text-xs font-mono uppercase tracking-widest text-white mb-3 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#F97316]" />
                    <span>Engineered Benefits & Execution Standard</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {service.keyBenefits.map((benefit, i) => (
                      <div key={i} className="flex items-start gap-2.5 text-xs text-[#A5A9AE]">
                        <CheckCircle2 className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5">
                  <h4 className="text-[11px] font-mono uppercase text-[#A5A9AE] mb-2">
                    Compatible Material Assemblies:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {service.materialsSupported.map((mat, i) => (
                      <span
                        key={i}
                        className="text-xs bg-[#24282D] text-white/90 px-3 py-1 rounded-sm border border-white/10"
                      >
                        {mat}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 text-xs text-[#A5A9AE] border-t border-white/5">
                  <span className="text-white font-medium">Recommended for: </span>
                  {service.suitableFor}
                </div>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Materials Comparison Guide */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-20 mt-12 border-t border-white/10">
        <div className="bg-[#24282D] border border-white/10 rounded-sm p-8 lg:p-12">
          <div className="max-w-2xl mb-8 space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Material Guide
            </span>
            <h3 className="font-space text-2xl sm:text-3xl font-bold text-white">
              Selecting the Optimal Material for North Texas.
            </h3>
            <p className="text-xs text-[#A5A9AE]">
              Comparative breakdown based on longevity, impact resistance, and thermal efficiency.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-inter border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[#A5A9AE] uppercase font-mono">
                  <th className="py-3 px-4">Roofing Profile</th>
                  <th className="py-3 px-4">Lifespan Expectancy</th>
                  <th className="py-3 px-4">Hail Impact Rating</th>
                  <th className="py-3 px-4">Thermal Reflection</th>
                  <th className="py-3 px-4">Best Architecture</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-white/90">
                <tr>
                  <td className="py-4 px-4 font-bold text-white">Standing Seam Metal (Kynar 500)</td>
                  <td className="py-4 px-4 font-mono">50+ Years</td>
                  <td className="py-4 px-4 text-[#F97316]">Class 4 (Highest)</td>
                  <td className="py-4 px-4">High (Cool Roof pigments)</td>
                  <td className="py-4 px-4 text-[#A5A9AE]">Contemporary, Modern Texas, Transitional</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-bold text-white">Designer Architectural Shingle</td>
                  <td className="py-4 px-4 font-mono">30–50 Years</td>
                  <td className="py-4 px-4 text-[#F97316]">Class 4 Available</td>
                  <td className="py-4 px-4">Moderate to High</td>
                  <td className="py-4 px-4 text-[#A5A9AE]">Traditional, Craftsman, Modern Gabled</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-bold text-white">Commercial Single-Ply TPO</td>
                  <td className="py-4 px-4 font-mono">25–30 Years</td>
                  <td className="py-4 px-4 text-[#F97316]">Puncture Reinforced</td>
                  <td className="py-4 px-4 text-emerald-400">Extreme (CRRC SRI 104)</td>
                  <td className="py-4 px-4 text-[#A5A9AE]">Commercial, Flat, Low-Slope Industrial</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-bold text-white">Synthetic Slate & Composite Tile</td>
                  <td className="py-4 px-4 font-mono">50+ Years</td>
                  <td className="py-4 px-4 text-[#F97316]">Class 4 (High Impact)</td>
                  <td className="py-4 px-4">Moderate</td>
                  <td className="py-4 px-4 text-[#A5A9AE]">Estate Mansions, Historic French & Mediterranean</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Global Services CTA */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="bg-[#17191C] border border-white/10 p-8 rounded-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="font-space text-xl font-bold text-white">Uncertain Which Solution Fits Your Property?</h4>
            <p className="text-xs text-[#A5A9AE] mt-1">Our estimators provide forensic assessments with itemized options.</p>
          </div>
          <button
            onClick={() => onOpenQuoteModal()}
            type="button"
            className="bg-[#F97316] hover:bg-[#EA580C] text-white px-7 py-3.5 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors whitespace-nowrap"
          >
            Request Free Site Assessment
          </button>
        </div>
      </section>
    </div>
  );
};
