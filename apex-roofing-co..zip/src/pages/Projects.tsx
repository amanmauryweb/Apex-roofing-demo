import React, { useState } from 'react';
import { PROJECTS_DATA, ProjectItem } from '../data/projects';
import { BeforeAfterSlider } from '../components/gallery/BeforeAfterSlider';
import { MapPin, Layers, Calendar, Filter, Maximize2, ShieldCheck, ArrowUpRight } from 'lucide-react';

interface ProjectsProps {
  onSelectProjectForLightbox: (index: number) => void;
  onOpenQuoteModal: (projectName?: string) => void;
}

export const Projects: React.FC<ProjectsProps> = ({
  onSelectProjectForLightbox,
  onOpenQuoteModal
}) => {
  const [activeFilter, setActiveFilter] = useState<'All' | 'Residential' | 'Commercial'>('All');

  const filteredProjects = PROJECTS_DATA.filter((p) => {
    if (activeFilter === 'All') return true;
    return p.category === activeFilter;
  });

  return (
    <div className="pt-28 pb-20 font-inter bg-[#17191C] text-white">
      {/* Hero Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="max-w-3xl space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            Architectural Portfolio
          </span>
          <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Selected Commissions.
          </h1>
          <p className="text-base sm:text-lg text-[#A5A9AE] font-light leading-relaxed">
            A curated portfolio of steep-slope luxury residential estates and high-performance commercial flat roof systems across the Dallas metropolitan area.
          </p>

          <div className="p-3 bg-[#24282D] border border-white/10 rounded-sm inline-flex items-center gap-2 text-xs text-[#A5A9AE]">
            <ShieldCheck className="w-4 h-4 text-[#F97316] shrink-0" />
            <span>Notice: All portfolio projects are demonstration architectural examples for review.</span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="mt-10 flex items-center gap-2 border-b border-white/10 pb-4">
          <span className="text-xs text-[#A5A9AE] mr-2 flex items-center gap-1 font-mono uppercase">
            <Filter className="w-3.5 h-3.5 text-[#F97316]" /> Category:
          </span>
          {(['All', 'Residential', 'Commercial'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors ${
                activeFilter === cat
                  ? 'bg-[#F97316] text-white'
                  : 'bg-[#24282D] text-[#A5A9AE] hover:text-white'
              }`}
            >
              {cat} ({cat === 'All' ? PROJECTS_DATA.length : PROJECTS_DATA.filter(p => p.category === cat).length})
            </button>
          ))}
        </div>
      </section>

      {/* Projects Grid */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {filteredProjects.map((project, idx) => {
            const globalIndex = PROJECTS_DATA.findIndex(p => p.id === project.id);
            return (
              <div
                key={project.id}
                className="bg-[#24282D] border border-white/10 rounded-sm overflow-hidden flex flex-col justify-between group hover:border-[#F97316]/50 transition-all duration-300 shadow-xl"
              >
                {/* Image Frame */}
                <div
                  onClick={() => onSelectProjectForLightbox(globalIndex)}
                  className="aspect-[16/10] overflow-hidden relative cursor-pointer"
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

                  {/* Top Badges */}
                  <div className="absolute top-4 left-4 flex items-center gap-2">
                    <span className="px-2.5 py-1 bg-[#17191C]/90 backdrop-blur-md rounded-sm text-[10px] font-mono uppercase text-[#F97316] border border-white/10">
                      {project.category}
                    </span>
                    <span className="px-2 py-1 bg-black/60 backdrop-blur-md rounded-sm text-[10px] font-mono text-[#A5A9AE]">
                      {project.year}
                    </span>
                  </div>

                  {/* Hover Inspect Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <span className="px-4 py-2 bg-[#F97316] text-white text-xs uppercase font-bold tracking-wider rounded-sm shadow-lg flex items-center gap-1.5">
                      <Maximize2 className="w-3.5 h-3.5" />
                      <span>View Lightbox</span>
                    </span>
                  </div>

                  {/* Location Tag */}
                  <div className="absolute bottom-4 left-4 text-xs text-[#A5A9AE] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#F97316]" />
                    <span>{project.location}</span>
                  </div>
                </div>

                {/* Details Body */}
                <div className="p-6 md:p-8 space-y-4 flex-1 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs font-mono text-[#F97316]">
                      <span>{project.roofType}</span>
                      <span className="text-[#A5A9AE]">Duration: {project.duration}</span>
                    </div>

                    <h3 className="font-space text-2xl font-bold text-white group-hover:text-[#F97316] transition-colors">
                      {project.title}
                    </h3>

                    <p className="text-xs text-[#A5A9AE] leading-relaxed">
                      {project.summary}
                    </p>

                    {/* Architectural Bullet Points */}
                    <div className="pt-2 space-y-1.5">
                      <span className="text-[10px] font-mono uppercase text-[#A5A9AE]">Architectural Highlights:</span>
                      {project.architecturalDetails.slice(0, 2).map((det, i) => (
                        <p key={i} className="text-xs text-white/80 flex items-start gap-2">
                          <span className="text-[#F97316] mt-0.5">·</span>
                          <span>{det}</span>
                        </p>
                      ))}
                    </div>
                  </div>

                  <div className="pt-6 mt-6 border-t border-white/5 flex items-center justify-between">
                    <button
                      onClick={() => onSelectProjectForLightbox(globalIndex)}
                      type="button"
                      className="text-xs uppercase font-bold tracking-wider text-white hover:text-[#F97316] transition-colors flex items-center gap-1"
                    >
                      <span>Full Case Specs</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onOpenQuoteModal(project.title)}
                      type="button"
                      className="text-xs text-[#F97316] hover:underline"
                    >
                      Inquire on Similar System
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Featured Before & After Interactive Showcase */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-16 border-t border-white/10">
        <div className="max-w-3xl mb-12 space-y-3">
          <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
            Case Study Comparison
          </span>
          <h2 className="font-space text-3xl sm:text-4xl font-bold text-white">
            Highland Park Valley Restoration.
          </h2>
          <p className="text-xs text-[#A5A9AE]">
            Examine the detail between the deteriorated original underlayment and the newly integrated 16oz copper pan and standing seam roof.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <BeforeAfterSlider
            beforeImage="/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg"
            afterImage="/src/assets/images/hero_architectural_roof_1793626321423.jpg"
            beforeLabel="Degraded Valley Flashing"
            afterLabel="Restored Copper & Standing Seam"
          />
        </div>
      </section>

      {/* Project Consultation CTA */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="bg-[#24282D] border border-white/10 p-8 lg:p-12 rounded-sm flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2 max-w-xl">
            <h3 className="font-space text-2xl font-bold text-white">
              Have a Similar Architecture in Mind?
            </h3>
            <p className="text-xs text-[#A5A9AE]">
              Our Dallas team provides material samples, finish swatches, and structural feasibility assessments for any residential or commercial project.
            </p>
          </div>

          <button
            onClick={() => onOpenQuoteModal()}
            type="button"
            className="bg-[#F97316] hover:bg-[#EA580C] text-white px-8 py-4 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors whitespace-nowrap shrink-0 shadow-lg"
          >
            Request Project Estimate
          </button>
        </div>
      </section>
    </div>
  );
};
