import React, { useState } from 'react';
import { TESTIMONIALS_DATA, DEMO_REVIEW_DISCLAIMER } from '../data/testimonials';
import { ShieldCheck, ExternalLink, Star, MessageSquare, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ReviewsProps {
  onOpenQuoteModal: () => void;
}

export const Reviews: React.FC<ReviewsProps> = ({ onOpenQuoteModal }) => {
  const [filterType, setFilterType] = useState<'All' | 'Residential' | 'Commercial'>('All');

  const filteredTestimonials = TESTIMONIALS_DATA.filter((t) => {
    if (filterType === 'All') return true;
    if (filterType === 'Residential') return t.clientType.includes('Residential') || t.clientType.includes('Homeowner') || t.clientType.includes('Architectural');
    if (filterType === 'Commercial') return t.clientType.includes('Commercial');
    return true;
  });

  return (
    <div className="pt-28 pb-20 font-inter bg-[#17191C] text-white">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="max-w-3xl space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            Demonstration Testimonials
          </span>
          <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
            Client Perspectives.
          </h1>
          <p className="text-base sm:text-lg text-[#A5A9AE] font-light leading-relaxed">
            Illustrative feedback examples demonstrating our project communications, technical precision, and site cleanliness standards across Dallas properties.
          </p>

          <div className="p-4 bg-[#24282D] border border-white/10 rounded-sm text-xs text-[#A5A9AE] space-y-1">
            <div className="flex items-center gap-2 text-white font-medium">
              <ShieldCheck className="w-4 h-4 text-[#F97316]" />
              <span>Ethical Disclosure Notice</span>
            </div>
            <p className="leading-relaxed">
              {DEMO_REVIEW_DISCLAIMER}
            </p>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="mt-10 flex items-center gap-2 border-b border-white/10 pb-4">
          <span className="text-xs text-[#A5A9AE] mr-2 font-mono uppercase">Filter Reviews:</span>
          {(['All', 'Residential', 'Commercial'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setFilterType(filter)}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors ${
                filterType === filter
                  ? 'bg-[#F97316] text-white'
                  : 'bg-[#24282D] text-[#A5A9AE] hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </section>

      {/* Reviews Grid */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredTestimonials.map((review) => (
            <div
              key={review.id}
              className="bg-[#24282D] border border-white/10 rounded-sm p-8 space-y-6 flex flex-col justify-between hover:border-white/20 transition-all duration-300"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <span className="text-xs font-mono uppercase tracking-wider text-[#F97316]">
                    {review.serviceCategory}
                  </span>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-[#17191C] text-[#A5A9AE] border border-white/5 rounded">
                    Demo Feedback
                  </span>
                </div>

                <h3 className="font-space text-lg font-bold text-white">
                  "{review.quoteHighlights}"
                </h3>

                <p className="text-sm text-[#A5A9AE] leading-relaxed font-light italic">
                  "{review.testimonialText}"
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-space font-bold text-white">{review.clientType}</h4>
                  <p className="text-[11px] text-[#A5A9AE]">{review.propertyContext}</p>
                </div>
                <div className="flex items-center gap-1 text-[#F97316]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#F97316]" />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Future Google Reviews Integration Container */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mb-16">
        <div className="bg-[#17191C] border border-dashed border-white/15 rounded-sm p-8 text-center space-y-3">
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center mx-auto text-[#A5A9AE]">
            <MessageSquare className="w-5 h-5" />
          </div>
          <h4 className="font-space text-lg font-bold text-white">
            Future Google Business Profile Integration
          </h4>
          <p className="text-xs text-[#A5A9AE] max-w-md mx-auto leading-relaxed">
            When deployed for live commercial operations, this portal will connect to the official Google Business Profile API to stream verified customer reviews and ratings in real time.
          </p>
          <div className="pt-2">
            <span className="inline-flex items-center gap-1.5 text-xs text-[#F97316] font-mono cursor-not-allowed opacity-80">
              <span>Google Review Feed [Configurable Placeholder]</span>
              <ExternalLink className="w-3 h-3" />
            </span>
          </div>
        </div>
      </section>

      {/* Estimate CTA */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="bg-gradient-to-r from-[#24282D] to-[#1D2024] border border-white/10 rounded-sm p-8 lg:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Experience the Apex Difference
            </span>
            <h3 className="font-space text-2xl sm:text-3xl font-bold text-white">
              Schedule Your Precision Estimate Today.
            </h3>
            <p className="text-xs text-[#A5A9AE]">
              Contact our Dallas estimating team to receive an itemized architectural breakdown of your roofing requirements.
            </p>
          </div>

          <button
            onClick={onOpenQuoteModal}
            type="button"
            className="bg-[#F97316] hover:bg-[#EA580C] text-white px-8 py-4 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors whitespace-nowrap shadow-xl shadow-[#F97316]/20"
          >
            Request Free Estimate
          </button>
        </div>
      </section>
    </div>
  );
};
