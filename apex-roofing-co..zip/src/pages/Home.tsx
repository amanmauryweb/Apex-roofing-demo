import React from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ArrowUpRight,
  Shield,
  Layers,
  Wrench,
  Building,
  CheckCircle,
  Clock,
  Compass,
  FileText,
  Hammer
} from 'lucide-react';
import { SERVICES_DATA } from '../data/services';
import { PROJECTS_DATA } from '../data/projects';
import { TESTIMONIALS_DATA, DEMO_REVIEW_DISCLAIMER } from '../data/testimonials';
import { FAQ_DATA } from '../data/faq';
import { BeforeAfterSlider } from '../components/gallery/BeforeAfterSlider';
import { ServiceAreaMap } from '../components/common/ServiceAreaMap';
import { FAQAccordion } from '../components/common/FAQAccordion';

interface HomeProps {
  onOpenQuoteModal: (defaultService?: string) => void;
  onSelectProjectForLightbox: (index: number) => void;
}

export const Home: React.FC<HomeProps> = ({
  onOpenQuoteModal,
  onSelectProjectForLightbox
}) => {
  return (
    <div className="font-inter">
      {/* ======================================================== */}
      {/* SECTION 1: HERO (Split Screen Architecture)             */}
      {/* ======================================================== */}
      <section className="relative min-h-[92vh] flex items-center pt-28 pb-16 lg:py-0 overflow-hidden bg-[#17191C]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Brand Statement & Editorial Typography */}
          <div className="lg:col-span-6 space-y-8 z-10">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 text-xs font-mono tracking-[0.25em] uppercase text-[#F97316]">
                <span className="w-2 h-2 rounded-full bg-[#F97316]" />
                <span>Dallas Architectural Roofing Contractor</span>
              </div>

              <h1 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.08]">
                Built to Protect.{' '}
                <span className="text-[#A5A9AE] block mt-1">Designed to Last.</span>
              </h1>

              <p className="text-base sm:text-lg text-[#A5A9AE] leading-relaxed max-w-xl font-light">
                Premium residential and commercial roofing solutions, delivered with precision, thoughtful craftsmanship, and a commitment to lasting protection across North Texas.
              </p>
            </div>

            {/* Call to Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={() => onOpenQuoteModal()}
                type="button"
                className="inline-flex items-center justify-center gap-2 bg-[#F97316] hover:bg-[#EA580C] text-white px-8 py-4 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-200 shadow-xl shadow-[#F97316]/20 active:scale-[0.98]"
              >
                <span>Request a Free Estimate</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <Link
                to="/projects"
                className="inline-flex items-center justify-center gap-2 bg-[#24282D] hover:bg-[#2C3138] text-white border border-white/10 px-7 py-4 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-200"
              >
                <span>Explore Our Work</span>
                <ArrowUpRight className="w-4 h-4 text-[#A5A9AE]" />
              </Link>
            </div>

            {/* Sub-hero Quality Statement */}
            <div className="pt-4 border-t border-white/10 flex items-center gap-6 text-xs text-[#A5A9AE]">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#F97316]" />
                <span>Engineered for Texas Weather Extremes</span>
              </div>
              <span className="text-white/20">·</span>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#F97316]" />
                <span>Residential & Commercial Expertise</span>
              </div>
            </div>
          </div>

          {/* Right Column: Architectural Photography Focal Carrier */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] lg:aspect-[5/4] rounded-sm overflow-hidden border border-white/10 shadow-2xl group">
              <img
                src="/src/assets/images/hero_architectural_roof_1793626321423.jpg"
                alt="Architectural modern residential roofing with standing seam metal and designer shingles in Dallas, Texas"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />

              {/* Architectural Spec Card Overlay */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#17191C]/90 backdrop-blur-md border border-white/10 rounded-sm flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#F97316] block">
                    Featured Architectural Commission
                  </span>
                  <p className="font-space text-sm font-bold text-white mt-0.5">
                    Highland Park Modern Residence
                  </p>
                  <p className="text-[11px] text-[#A5A9AE]">
                    24-Gauge Standing Seam Metal & Class 4 Laminated Shingles
                  </p>
                </div>
                <Link
                  to="/projects"
                  className="p-2.5 bg-[#24282D] hover:bg-[#F97316] text-white rounded-sm border border-white/10 transition-colors shrink-0"
                  aria-label="View project case study"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 2: TRUST INDICATORS STRIP                        */}
      {/* ======================================================== */}
      <section className="bg-[#24282D] border-y border-white/10 py-6">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-space text-sm font-bold text-white uppercase tracking-tight">Residential Roofing</h4>
                <p className="text-[11px] text-[#A5A9AE]">Custom homes & estates</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-space text-sm font-bold text-white uppercase tracking-tight">Commercial Roofing</h4>
                <p className="text-[11px] text-[#A5A9AE]">TPO, PVC & flat systems</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-space text-sm font-bold text-white uppercase tracking-tight">Quality Workmanship</h4>
                <p className="text-[11px] text-[#A5A9AE]">Meticulous installation</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-[#17191C] border border-white/10 flex items-center justify-center text-[#F97316] shrink-0">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-space text-sm font-bold text-white uppercase tracking-tight">Dallas Area Service</h4>
                <p className="text-[11px] text-[#A5A9AE]">North Texas coverage</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 3: SERVICES OVERVIEW (Light Architectural Grid)  */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#F5F5F2] text-[#17191C]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
                Specialized Capabilities
              </span>
              <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#17191C]">
                Complete Roofing Solutions.
              </h2>
            </div>
            <p className="text-sm text-neutral-600 max-w-md font-light leading-relaxed">
              Every roof is an engineered system. We pair structural integrity with architectural refinement to deliver uncompromising longevity.
            </p>
          </div>

          {/* 7 Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES_DATA.map((service) => (
              <div
                key={service.id}
                className="group bg-white border border-neutral-200/80 rounded-sm p-8 flex flex-col justify-between hover:shadow-xl hover:border-neutral-300 transition-all duration-300 relative overflow-hidden"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                    <span className="text-xs font-mono font-bold text-[#F97316]">
                      {service.number}
                    </span>
                    <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 bg-neutral-100 text-neutral-600 rounded">
                      {service.category}
                    </span>
                  </div>

                  <h3 className="font-space text-xl font-bold text-[#17191C] group-hover:text-[#F97316] transition-colors">
                    {service.title}
                  </h3>

                  <p className="text-xs text-neutral-600 leading-relaxed">
                    {service.description}
                  </p>

                  <div className="pt-2">
                    <span className="text-[11px] font-mono text-neutral-400 block mb-1">Key Specification:</span>
                    <p className="text-xs font-medium text-neutral-700 line-clamp-1">
                      {service.keyBenefits[0]}
                    </p>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-neutral-100 flex items-center justify-between">
                  <Link
                    to={`/services#${service.id}`}
                    className="text-xs font-bold uppercase tracking-wider text-[#17191C] group-hover:text-[#F97316] inline-flex items-center gap-1.5 transition-colors"
                  >
                    <span>Learn More</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>

                  <button
                    onClick={() => onOpenQuoteModal(service.title)}
                    type="button"
                    className="text-xs text-[#F97316] hover:underline"
                  >
                    Quick Estimate
                  </button>
                </div>
              </div>
            ))}

            {/* 8th Card: Custom Architectural Consultation */}
            <div className="bg-[#17191C] text-white border border-white/10 rounded-sm p-8 flex flex-col justify-between shadow-lg">
              <div className="space-y-4">
                <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316]">
                  Custom Commission
                </span>
                <h3 className="font-space text-2xl font-bold text-white">
                  Have a Complex Blueprint?
                </h3>
                <p className="text-xs text-[#A5A9AE] leading-relaxed">
                  We consult directly with residential architects, custom home builders, and commercial developers on specialized roof geometrics.
                </p>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => onOpenQuoteModal('Custom Blueprint Consultation')}
                  type="button"
                  className="w-full bg-[#F97316] hover:bg-[#EA580C] text-white py-3.5 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors text-center"
                >
                  Consult an Estimator
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 4: ABOUT PREVIEW (Editorial Image & Text)        */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#17191C] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Image Column */}
            <div className="lg:col-span-5 order-2 lg:order-1">
              <div className="relative rounded-sm overflow-hidden border border-white/10 shadow-2xl aspect-[4/3]">
                <img
                  src="/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg"
                  alt="Close-up architectural detail of precision roofing metal and tile craftsmanship"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 right-4 text-xs text-[#A5A9AE] font-mono">
                  Custom copper valley transition · Highland Park Commission
                </div>
              </div>
            </div>

            {/* Text Column */}
            <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
                Philosophy & Craftsmanship
              </span>

              <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
                More Than a Roof.{' '}
                <span className="text-[#A5A9AE] block">A Commitment to Protection.</span>
              </h2>

              <p className="text-sm md:text-base text-[#A5A9AE] leading-relaxed font-light">
                At Apex Roofing Co., we view roofing not as an incidental construction trade, but as the foundational shield defending an architectural investment. Every valley, penetration, and ridge cap represents a vital juncture where design meets extreme natural elements.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                <div className="space-y-2 border-l border-[#F97316]/40 pl-4">
                  <h4 className="font-space text-sm font-bold text-white">Attention to Detail</h4>
                  <p className="text-xs text-[#A5A9AE] leading-relaxed">
                    Custom hand-bent flashing and precision underlayment overlapping ensure subterranean water tightness.
                  </p>
                </div>

                <div className="space-y-2 border-l border-[#F97316]/40 pl-4">
                  <h4 className="font-space text-sm font-bold text-white">Transparent Handling</h4>
                  <p className="text-xs text-[#A5A9AE] leading-relaxed">
                    Photographic daily progress logs and honest material specifications with zero hidden markups.
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white hover:text-[#F97316] transition-colors"
                >
                  <span>Read Our Full Brand Story</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 5: FEATURED PROJECTS                             */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#1E2227] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
                Portfolio Showcase
              </span>
              <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
                Featured Commissions.
              </h2>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-[#A5A9AE]">
                *Demonstration portfolio entries illustrating architectural execution.
              </p>
              <Link
                to="/projects"
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#F97316] hover:text-white transition-colors"
              >
                <span>View Complete Gallery</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PROJECTS_DATA.slice(0, 3).map((project, idx) => (
              <div
                key={project.id}
                onClick={() => onSelectProjectForLightbox(idx)}
                className="group cursor-pointer bg-[#17191C] border border-white/10 rounded-sm overflow-hidden hover:border-[#F97316]/50 transition-all duration-300 shadow-xl"
              >
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-3 left-3 bg-[#17191C]/90 backdrop-blur-md px-2.5 py-1 rounded text-[10px] font-mono uppercase text-[#A5A9AE] border border-white/10">
                    {project.category}
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="px-4 py-2 bg-[#F97316] text-white text-xs uppercase font-bold tracking-wider rounded-sm shadow-md">
                      Inspect Project
                    </span>
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <span className="text-[11px] font-mono text-[#F97316] block">
                    {project.roofType}
                  </span>
                  <h3 className="font-space text-lg font-bold text-white group-hover:text-[#F97316] transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-xs text-[#A5A9AE] line-clamp-2">
                    {project.summary}
                  </p>
                  <div className="pt-2 text-[11px] text-[#A5A9AE]/80 flex items-center justify-between border-t border-white/5">
                    <span>{project.location}</span>
                    <span className="text-white font-mono">{project.duration}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 6: BEFORE AND AFTER (Interactive Slider)         */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#17191C] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
              Transformation Precision
            </span>
            <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Before & After Comparison.
            </h2>
            <p className="text-sm text-[#A5A9AE]">
              Drag the center slider to inspect the architectural difference between weathered original materials and precision standing seam roofing.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <BeforeAfterSlider
              beforeImage="/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg"
              afterImage="/src/assets/images/hero_architectural_roof_1793626321423.jpg"
              beforeLabel="Pre-Restoration Detail"
              afterLabel="Restored Architectural Residence"
              caption="Demonstration comparative analysis showing structural underlayment renewal and zero-exposed-fastener standing seam transitions."
            />
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 7: WHY CHOOSE APEX (4 Editorial Blocks)         */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#24282D] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="max-w-2xl mb-16 space-y-3">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
              The Apex Standard
            </span>
            <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Engineered for Discerning Owners.
            </h2>
            <p className="text-sm text-[#A5A9AE]">
              Four pillars defining our commitment to architectural protection across Dallas and surrounding cities.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-[#17191C] border border-white/10 p-6 rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-sm bg-[#24282D] border border-white/10 flex items-center justify-center text-[#F97316]">
                <Compass className="w-5 h-5" />
              </div>
              <h3 className="font-space text-lg font-bold text-white">
                Precision-Focused Approach
              </h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Detailed substrate inspection, forensic leak diagnosis, and laser-guided alignment of standing seam panels.
              </p>
            </div>

            <div className="bg-[#17191C] border border-white/10 p-6 rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-sm bg-[#24282D] border border-white/10 flex items-center justify-center text-[#F97316]">
                <Building className="w-5 h-5" />
              </div>
              <h3 className="font-space text-lg font-bold text-white">
                Residential & Commercial
              </h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Seamless competence across high-end steep-slope architectural homes and expansive commercial single-ply TPO roofs.
              </p>
            </div>

            <div className="bg-[#17191C] border border-white/10 p-6 rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-sm bg-[#24282D] border border-white/10 flex items-center justify-center text-[#F97316]">
                <FileText className="w-5 h-5" />
              </div>
              <h3 className="font-space text-lg font-bold text-white">
                Clear Communication
              </h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Transparent daily milestones, itemized pricing schedules, and direct access to your dedicated project manager.
              </p>
            </div>

            <div className="bg-[#17191C] border border-white/10 p-6 rounded-sm space-y-4">
              <div className="w-10 h-10 rounded-sm bg-[#24282D] border border-white/10 flex items-center justify-center text-[#F97316]">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-space text-lg font-bold text-white">
                Custom Architectural Fit
              </h3>
              <p className="text-xs text-[#A5A9AE] leading-relaxed">
                Every solution is calibrated to match the specific geometry, ventilation needs, and sun exposure of your property.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 8: WORK PROCESS (4-Step Visual Process)          */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#17191C] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
                Project Lifecycle
              </span>
              <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
                Our Work Process.
              </h2>
            </div>
            <p className="text-xs text-[#A5A9AE] max-w-sm">
              Structured execution designed to deliver flawless results with zero surprises from consultation to final cleanup.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: "01",
                title: "Initial Enquiry",
                desc: "Submit your project requirements online. Our estimating team reviews property satellite blueprints and responds within 24 hours.",
                icon: FileText
              },
              {
                step: "02",
                title: "Project Assessment",
                desc: "An on-site forensic inspection evaluates decking integrity, attic ventilation, flashing conditions, and structural load points.",
                icon: Compass
              },
              {
                step: "03",
                title: "Roofing Proposal",
                desc: "You receive an itemized architectural proposal detailing material specifications, warranties, timeline stages, and investment tiers.",
                icon: CheckCircle
              },
              {
                step: "04",
                title: "Project Execution",
                desc: "Certified crews execute the installation with strict safety protocols, magnetic ground sweeps, and daily progress documentation.",
                icon: Hammer
              }
            ].map((st) => {
              const Icon = st.icon;
              return (
                <div key={st.step} className="bg-[#24282D] border border-white/10 p-6 rounded-sm space-y-4 relative">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-space font-bold text-[#F97316]">
                      {st.step}
                    </span>
                    <Icon className="w-5 h-5 text-[#A5A9AE]" />
                  </div>
                  <h3 className="font-space text-lg font-bold text-white">
                    {st.title}
                  </h3>
                  <p className="text-xs text-[#A5A9AE] leading-relaxed">
                    {st.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 9: TESTIMONIALS (Demo Testimonials)              */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#1E2227] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
              Client Perspectives
            </span>
            <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Demonstration Testimonials.
            </h2>
            <p className="text-xs text-[#A5A9AE]">
              {DEMO_REVIEW_DISCLAIMER}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TESTIMONIALS_DATA.map((t) => (
              <div
                key={t.id}
                className="bg-[#17191C] border border-white/10 p-8 rounded-sm space-y-6 relative flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <span className="text-[10px] font-mono uppercase text-[#F97316]">
                      {t.serviceCategory}
                    </span>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-white/5 text-[#A5A9AE] rounded">
                      Demo Feedback
                    </span>
                  </div>

                  <p className="text-sm text-white/90 leading-relaxed font-light italic">
                    "{t.testimonialText}"
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs">
                  <div>
                    <h4 className="font-space font-bold text-white">{t.clientType}</h4>
                    <p className="text-[11px] text-[#A5A9AE]">{t.propertyContext}</p>
                  </div>
                  <div className="text-[#F97316] text-xs font-mono">
                    ★★★★★
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              to="/reviews"
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#A5A9AE] hover:text-white transition-colors"
            >
              <span>Explore All Feedback Formats</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 10: SERVICE AREA (Interactive Topology)          */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#17191C] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <ServiceAreaMap />
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 11: FAQ (Working Accordion)                      */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#24282D] border-b border-white/10">
        <div className="max-w-4xl mx-auto px-6 lg:px-12">
          <div className="text-center mb-16 space-y-4">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#F97316] font-bold">
              Common Questions
            </span>
            <h2 className="font-space text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Roofing FAQs.
            </h2>
            <p className="text-xs text-[#A5A9AE]">
              Concise answers to frequent questions regarding our inspection, replacement, and materials.
            </p>
          </div>

          <FAQAccordion items={FAQ_DATA} />
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 12: FINAL CTA                                    */}
      {/* ======================================================== */}
      <section className="py-24 md:py-32 bg-[#17191C] relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-6 lg:px-12 text-center space-y-8 relative z-10">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-[#F97316] font-bold">
            Dallas & Surrounding Cities
          </span>

          <h2 className="font-space text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-tight">
            Let's Protect What Matters.
          </h2>

          <p className="text-base sm:text-lg text-[#A5A9AE] max-w-xl mx-auto font-light leading-relaxed">
            Tell us about your roofing project and take the first step toward a better roofing solution with precision engineering and thoughtful craftsmanship.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onOpenQuoteModal()}
              type="button"
              className="w-full sm:w-auto bg-[#F97316] hover:bg-[#EA580C] text-white px-9 py-4 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-200 shadow-xl shadow-[#F97316]/20 active:scale-[0.98]"
            >
              Request a Free Estimate
            </button>

            <Link
              to="/contact"
              className="w-full sm:w-auto bg-[#24282D] hover:bg-[#2C3138] text-white border border-white/10 px-8 py-4 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-200"
            >
              Visit Contact Page
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
