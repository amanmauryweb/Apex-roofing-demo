/**
 * Centralized Business Configuration for Apex Roofing Co.
 * All phone, email, and location details are editable demonstration placeholders.
 */

export interface BusinessConfig {
  name: string;
  shortName: string;
  tagline: string;
  location: string;
  city: string;
  state: string;
  coverage: string;
  coverageCities: string[];
  phonePlaceholder: string;
  emailPlaceholder: string;
  isLiveContactActive: boolean; // Set to true only when real client credentials are wired
  disclaimer: string;
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
  socials: {
    name: string;
    href: string;
    isPlaceholder: boolean;
  }[];
}

export const BUSINESS_CONFIG: BusinessConfig = {
  name: "Apex Roofing Co.",
  shortName: "Apex Roofing",
  tagline: "Built to Protect. Designed to Last.",
  location: "Dallas, Texas, USA",
  city: "Dallas",
  state: "Texas",
  coverage: "Dallas and surrounding North Texas communities",
  coverageCities: [
    "Dallas",
    "Highland Park",
    "University Park",
    "Plano",
    "Frisco",
    "Southlake",
    "Richardson",
    "McKinney",
    "Fort Worth",
    "Irving",
    "Grapevine",
    "Carrollton"
  ],
  phonePlaceholder: "+1 (XXX) XXX-XXXX",
  emailPlaceholder: "hello@example.com",
  isLiveContactActive: false, // Ensures placeholders are not dialed or emailed unintentionally
  disclaimer: "Apex Roofing Co. is a demonstration architectural portfolio project. All projects, reviews, and contact credentials shown are illustrative.",
  hours: {
    weekdays: "Monday – Friday: 7:00 AM – 6:00 PM",
    saturday: "Saturday: 8:00 AM – 2:00 PM (By Appointment)",
    sunday: "Sunday: Closed (Emergency Dispatch On-Call)"
  },
  socials: [
    { name: "Instagram", href: "#", isPlaceholder: true },
    { name: "LinkedIn", href: "#", isPlaceholder: true },
    { name: "Architectural Digest Pro", href: "#", isPlaceholder: true }
  ]
};
