export interface ProjectItem {
  id: string;
  title: string;
  category: 'Residential' | 'Commercial';
  roofType: string;
  location: string; // Fictional/illustrative
  year: string;
  duration: string;
  image: string;
  beforeImage?: string;
  afterImage?: string;
  summary: string;
  architecturalDetails: string[];
  materialsUsed: string[];
  isFeatured: boolean;
  isDemonstrationPortfolio: boolean;
}

export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: "highland-park-modern",
    title: "The Highland Park Estate",
    category: "Residential",
    roofType: "Standing Seam Matte Charcoal & Designer Shingle",
    location: "Highland Park, TX (Illustrative)",
    year: "2025",
    duration: "4 Days",
    image: "/src/assets/images/hero_architectural_roof_1793626321423.jpg",
    beforeImage: "/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg",
    afterImage: "/src/assets/images/hero_architectural_roof_1793626321423.jpg",
    summary: "Architectural replacement marrying 24-gauge matte charcoal standing seam metal gables with Class 4 impact architectural laminated shingles on a custom contemporary residence.",
    architecturalDetails: [
      "Zero-exposed fastener standing seam panels on cantilevered balcony roofs",
      "Custom continuous ridge ventilation matching the exact roof profile pitch",
      "Seamless integration with deep eaves overhangs and hidden gutters",
      "Thermal radiant barrier underlayment mitigating North Texas summer heat transfer"
    ],
    materialsUsed: [
      "Drexel Metals 24-Gauge Kynar 500 Matte Charcoal",
      "CertainTeed Landmark Pro Max Def Weathered Wood",
      "Titanium PSU30 Self-Adhering High-Temp Underlayment"
    ],
    isFeatured: true,
    isDemonstrationPortfolio: true
  },
  {
    id: "preston-hollow-contemporary",
    title: "Preston Hollow Residence",
    category: "Residential",
    roofType: "Precision Slate-Tone Architectural Composite",
    location: "Preston Hollow, Dallas, TX (Illustrative)",
    year: "2024",
    duration: "3 Days",
    image: "/src/assets/images/project_residential_modern_1793626323900.jpg",
    beforeImage: "/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg",
    afterImage: "/src/assets/images/project_residential_modern_1793626323900.jpg",
    summary: "A steep-slope transformation combining natural stone facades with a high-definition shingle geometry engineered for 130 MPH wind resistance.",
    architecturalDetails: [
      "Custom fabricated copper step flashing along Austin limestone walls",
      "Enhanced soffit intake baffling preventing attic thermal dead zones",
      "Multi-dimensional shadow band profile accentuating gabled rooflines",
      "Class A fire rating and Class 4 impact resistance certification"
    ],
    materialsUsed: [
      "GAF Timberline UHDZ Dual Shadow Charcoal",
      "Custom 16oz Hand-Soldered Copper Valleys & Crickets",
      "GAF Deck-Armor Breathable Synthetic Underlayment"
    ],
    isFeatured: true,
    isDemonstrationPortfolio: true
  },
  {
    id: "tech-district-corporate",
    title: "Tech District Corporate Center",
    category: "Commercial",
    roofType: "Energy-Efficient 80-mil TPO Single-Ply Membrane",
    location: "Dallas North Corridor, TX (Illustrative)",
    year: "2025",
    duration: "10 Days (Phased)",
    image: "/src/assets/images/project_commercial_tpo_1793626324115.jpg",
    summary: "Complete tear-off and replacement of an 48,000 sq ft aging modified bitumen roof with a high-solar-reflectance 80-mil white TPO membrane system.",
    architecturalDetails: [
      "Tapered polyisocyanurate insulation creating positive slope to 14 scuppers",
      "Robotic hot-air welded seams inspected via continuous peel testing",
      "Custom 20-gauge prefabricated perimeter coping with ES-1 wind uplift compliance",
      "Reflective Solar Reflectance Index (SRI) of 104 reducing summer cooling loads"
    ],
    materialsUsed: [
      "Carlisle SynTec Sure-Weld 80-mil Reinforced White TPO",
      "Carlisle Polyiso Tapered Insulation Boards",
      "Heavy-Duty Yellow Slip-Resistant Rooftop Walkway Pads"
    ],
    isFeatured: true,
    isDemonstrationPortfolio: true
  },
  {
    id: "artisan-valley-craft",
    title: "Precision Copper & Slate Valley Transition",
    category: "Residential",
    roofType: "Custom Copper Flashing & Architectural Slate Profile",
    location: "Turtle Creek, Dallas, TX (Illustrative)",
    year: "2024",
    duration: "2 Days",
    image: "/src/assets/images/roof_craftsmanship_detail_1793626323802.jpg",
    summary: "Detailed restoration of a complex roof juncture featuring hand-formed copper valley pans, riveted seams, and precision slate interlocking.",
    architecturalDetails: [
      "Continuous expansion clips allowing seasonal metal thermal movement",
      "Lead-free hand-soldered junction plates behind chimney counter-flashing",
      "Triple-layer membrane isolation preventing galvanic corrosion between dissimilar metals",
      "Architectural lifetime durability designed to exceed 50+ years"
    ],
    materialsUsed: [
      "Revere Architectural 16oz Cold-Rolled Copper",
      "High-Grade Synthetic Slate Shingles",
      "Grace Ice & Water Shield High-Temp HT Membrane"
    ],
    isFeatured: true,
    isDemonstrationPortfolio: true
  }
];
