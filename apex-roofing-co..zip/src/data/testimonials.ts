export interface TestimonialItem {
  id: string;
  clientType: string;
  propertyContext: string;
  serviceCategory: string;
  testimonialText: string;
  quoteHighlights: string;
  isDemoReview: true;
}

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    id: "demo-rev-01",
    clientType: "Residential Client Representative",
    propertyContext: "Custom Modern Gable Home, North Dallas",
    serviceCategory: "Roof Replacement & Standing Seam Metal",
    testimonialText: "The team approached our roof not merely as a shingle task, but as a critical architectural line. The standing seam metal transitions on our front gables are clean, knife-sharp, and solved a recurring leak our previous contractor couldn't diagnose.",
    quoteHighlights: "Clean, knife-sharp transitions and exceptional architectural care.",
    isDemoReview: true
  },
  {
    id: "demo-rev-02",
    clientType: "Commercial Property Manager",
    propertyContext: "Multi-Tenant Corporate Office, Dallas Corridor",
    serviceCategory: "Commercial TPO Membrane Replacement",
    testimonialText: "Replacing 45,000 square feet of commercial flat roof while corporate tenants occupied the building required tight staging and communication. Apex delivered without a single drop of interior disruption, completed ahead of deadline.",
    quoteHighlights: "Zero tenant disruption across 45,000 square feet of phased commercial roofing.",
    isDemoReview: true
  },
  {
    id: "demo-rev-03",
    clientType: "Architectural Designer & Homeowner",
    propertyContext: "Mid-Century Modern Renovation, Dallas",
    serviceCategory: "Designer Shingle Installation & Flashing Restoration",
    testimonialText: "From the initial drone diagnostic report to the daily site cleanup, the craftsmanship standard was consistently high. The custom fabricated copper flashing details around our stone chimney are works of art in their own right.",
    quoteHighlights: "Drone diagnostic precision and custom hand-crafted copper flashing.",
    isDemoReview: true
  },
  {
    id: "demo-rev-04",
    clientType: "Residential Homeowner",
    propertyContext: "Highland Park Spanish Tile & Underlayment Repair",
    serviceCategory: "Storm Damage Restoration & Tile Tuning",
    testimonialText: "Following a severe spring hailstorm, Apex conducted a thorough photographic assessment. Instead of pushing for an unnecessary full tear-off, they isolated compromised underlayment zones and preserved our original tiles.",
    quoteHighlights: "Objective, honest assessment without high-pressure sales tactics.",
    isDemoReview: true
  }
];

export const DEMO_REVIEW_DISCLAIMER = "Notice: All testimonials on this page are demonstration portfolio entries designed to illustrate client feedback formats. They do not represent third-party verified consumer reviews.";
