export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  extendedOverview: string;
  category: 'residential' | 'commercial' | 'both';
  icon: string;
  keyBenefits: string[];
  materialsSupported: string[];
  suitableFor: string;
  estimatedTimeline: string;
  warrantyHighlight: string;
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "roof-replacement",
    number: "01",
    title: "Roof Replacement",
    tagline: "Total architectural renewal with precision engineered underlayments.",
    description: "Complete tear-off and replacement engineered to withstand intense Texas sun, hail, and torrential storms with architectural grade materials.",
    extendedOverview: "Our roof replacement service begins with an exhaustive deck assessment to identify any subterranean decking rot or moisture intrusion. We then install multi-tier ice and water barriers, high-permeability synthetic underlayments, and custom precision-bent ridge caps for flawless water shedding.",
    category: "both",
    icon: "Layers",
    keyBenefits: [
      "Full structural deck inspection & re-nailing",
      "Class 4 impact-resistant material options for hail mitigation",
      "Enhanced attic ventilation balancing (intake vs. exhaust)",
      "Continuous lifetime wind and algae warranty protections"
    ],
    materialsSupported: ["Architectural Asphalt Shingles", "Standing Seam Steel/Aluminum", "Synthetic Slate & Tile", "Cedar Shake Alternatives"],
    suitableFor: "Aging roofs (15–25+ years), persistent multi-point leaks, or extensive storm deterioration.",
    estimatedTimeline: "1–3 Days depending on property footprint",
    warrantyHighlight: "Comprehensive workmanship warranty + manufacturer limited lifetime warranty"
  },
  {
    id: "roof-repair",
    number: "02",
    title: "Roof Repair",
    tagline: "Surgical leak intervention and targeted structural restoration.",
    description: "Fast, precise diagnostics and high-durability repairs for flashing failures, pipe boots, wind blow-offs, and localized punctures.",
    extendedOverview: "Rather than applying temporary caulk patches, our craftsmen trace leaks back to their exact origin—frequently hidden behind masonry counter-flashing, dead valleys, or skylight transitions. We replace damaged sub-flashings with custom copper or Kynar-coated steel.",
    category: "both",
    icon: "Wrench",
    keyBenefits: [
      "Infrared thermographic moisture mapping",
      "Matching existing shingle dye lots and textures seamlessly",
      "Chimney crickets and custom soldered valley pans",
      "Immediate stabilization to prevent interior finish damage"
    ],
    materialsSupported: ["All Asphalt Profiles", "Metal Panels & Seams", "Concrete & Clay Tile", "Modified Bitumen"],
    suitableFor: "Isolated leaks, wind-lifted tabs, compromised penetrations, or gutter overflow backing.",
    estimatedTimeline: "Same-day or next-day turnaround",
    warrantyHighlight: "1-Year targeted workmanship guarantee on all restored penetration zones"
  },
  {
    id: "new-roof-installation",
    number: "03",
    title: "New Roof Installation",
    tagline: "Architectural collaboration for custom new construction builds.",
    description: "Engineering tailored roofing systems from blueprints up, collaborating closely with North Texas custom home builders and architects.",
    extendedOverview: "For high-end new residential and commercial structures, roofing is a defining architectural crown. We coordinate with general contractors, structural engineers, and framers to ensure thermal envelopment, eaves overhang drip details, and clean geometric lines.",
    category: "both",
    icon: "Building",
    keyBenefits: [
      "BIM and CAD architectural specification compliance",
      "Custom fabrication of standing seam panels and zinc reveals",
      "Integrated concealed guttering and hidden downspout systems",
      "Zero-compromise clean jobsite standards throughout framing"
    ],
    materialsSupported: ["Custom Standing Seam Metal", "Natural Vermont Slate", "Ludowici Terracotta Tile", "Designer Multi-Laminate Shingles"],
    suitableFor: "Custom luxury residences, architectural renovations, and commercial new builds.",
    estimatedTimeline: "Integrated into builder construction schedule",
    warrantyHighlight: "Full architectural compliance guarantee and structural warranty"
  },
  {
    id: "commercial-roofing",
    number: "04",
    title: "Commercial Roofing",
    tagline: "High-performance low-slope systems for commercial and industrial facilities.",
    description: "Turnkey installation, coating, and maintenance of energy-efficient TPO, PVC, and modified bitumen roofing assemblies for Dallas commercial assets.",
    extendedOverview: "Commercial roofs endure extreme thermal cycling on large square-footage spans. We specialize in mechanically attached and fully adhered reflective single-ply membranes that dramatically reduce HVAC load while offering robust puncture and chemical resistance.",
    category: "commercial",
    icon: "Shield",
    keyBenefits: [
      "Energy Star & Cool Roof Rating Council (CRRC) compliant reflective white membranes",
      "Tapered ISO insulation design for positive drainage and zero ponding water",
      "Heavy-duty walk pads for rooftop HVAC maintenance protection",
      "Minimal operational disruption for tenants and commercial operations"
    ],
    materialsSupported: ["60 & 80 mil TPO Single-Ply", "Chemical-Resistant PVC", "SBS Modified Bitumen", "Silicone Fluid-Applied Restoration Coatings"],
    suitableFor: "Warehouses, office parks, retail centers, schools, and multi-family residential complexes.",
    estimatedTimeline: "Phased project staging based on square footage",
    warrantyHighlight: "Up to 30-Year NDL (No Dollar Limit) manufacturer warranties available"
  },
  {
    id: "roof-inspection",
    number: "05",
    title: "Roof Inspection",
    tagline: "Objective engineering assessments and high-resolution diagnostic reports.",
    description: "Detailed multi-point structural evaluations utilizing digital photographic documentation, drone imagery, and moisture detection.",
    extendedOverview: "Whether evaluating a property before acquisition or checking for subtle micro-fractures following a severe Texas thunderstorm, our comprehensive audit delivers a clean, transparent digital report outlining remaining useful lifespan, urgent defects, and proactive maintenance priorities.",
    category: "both",
    icon: "CheckCircle",
    keyBenefits: [
      "42-point photographic inspection checklist",
      "High-resolution 4K aerial drone mapping for steep or fragile surfaces",
      "Detailed written condition analysis with no high-pressure sales tactics",
      "Documentation acceptable for insurance valuation and escrow real estate closing"
    ],
    materialsSupported: ["All residential and commercial roof types and sloped substrates"],
    suitableFor: "Pre-purchase home buyers, post-storm checks, annual preventive audits, and asset managers.",
    estimatedTimeline: "1.5–3 hours on-site, report delivered in 24 hours",
    warrantyHighlight: "Certified condition audit report signed by senior roofing technician"
  },
  {
    id: "storm-damage-restoration",
    number: "06",
    title: "Storm Damage Restoration",
    tagline: "Rapid post-storm emergency response and precision structural restoration.",
    description: "Restoring residential and commercial properties affected by North Texas severe hail, tornado-force winds, and falling tree impacts.",
    extendedOverview: "Texas is notorious for erratic severe weather events. Hail impacts can bruise shingle asphalt fiberglass backing without showing catastrophic exterior tearing, leading to rapid deterioration within 6 months. We perform unbiased forensic impact analysis to restore properties to pristine condition.",
    category: "both",
    icon: "CloudLightning",
    keyBenefits: [
      "Rapid tarping and weatherization dispatch to contain interior water damage",
      "Forensic hail strike counting and collateral damage documentation (gutters, AC fins, skylights)",
      "Itemized Xactimate-compatible scope of work for total clarity",
      "Class 4 impact-resistant upgrades to minimize future hail risks"
    ],
    materialsSupported: ["Impact-Resistant Shingles (UL 2218 Class 4)", "24-Gauge Standing Seam Metal", "Heavy Commercial Membrane Systems"],
    suitableFor: "Properties affected by golf-ball or larger hail, high-velocity straight-line winds, or wind-blown debris.",
    estimatedTimeline: "Emergency tarping within hours; complete restoration scheduled swiftly",
    warrantyHighlight: "Comprehensive hail & wind installation warranty certificate"
  },
  {
    id: "roofing-maintenance",
    number: "07",
    title: "Roofing Maintenance",
    tagline: "Proactive stewardship extending total roof operational longevity.",
    description: "Scheduled preventive maintenance programs clearing debris, re-sealing pitch pockets, clearing internal drains, and tuning vulnerable points.",
    extendedOverview: "A neglected roof can lose 30% to 50% of its anticipated service lifespan. Our bi-annual commercial and residential maintenance regimens clear leaf dams from internal roof valleys, re-torque mechanical fasteners, refresh UV-exposed mastics, and ensure clear scuppers before rainy seasons hit.",
    category: "both",
    icon: "CalendarCheck",
    keyBenefits: [
      "Bi-annual spring and autumn preventive inspections",
      "Clearing rooftop valleys, scuppers, gutters, and downspout debris",
      "Preventive re-caulking of flashing counter-seals and pipe boots",
      "Detailed annual maintenance logbook protecting manufacturer warranty covenants"
    ],
    materialsSupported: ["Residential Shingle, Tile & Metal", "Commercial Single-Ply & Built-Up Roofs"],
    suitableFor: "Building owners and homeowners committed to maximizing ROI and preventing surprise emergencies.",
    estimatedTimeline: "Scheduled bi-annual service visits (Spring / Autumn)",
    warrantyHighlight: "Service priority status for maintenance plan holders during severe weather events"
  }
];
