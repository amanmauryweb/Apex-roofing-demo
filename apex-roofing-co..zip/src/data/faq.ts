export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'general' | 'services' | 'commercial' | 'estimates';
}

export const FAQ_DATA: FAQItem[] = [
  {
    id: "faq-services",
    question: "What roofing services do you offer?",
    answer: "Apex Roofing Co. specializes in seven core services: Roof Replacement, Precision Roof Repair, New Roof Installation for custom builders, Commercial Low-Slope & Flat Roofing (TPO/PVC/Modified Bitumen), Forensic Roof Inspections, Storm Damage Restoration, and Scheduled Preventive Roofing Maintenance programs.",
    category: "services"
  },
  {
    id: "faq-res-comm",
    question: "Do you work on both residential and commercial properties?",
    answer: "Yes. Our team has dedicated crews tailored for both high-end residential architectural steep-slope roofing (including standing seam metal, designer architectural shingles, slate, and tile) and large-scale commercial flat roof assemblies (single-ply TPO/PVC membranes, coatings, and multi-ply built-up systems).",
    category: "general"
  },
  {
    id: "faq-when-replace",
    question: "When should a roof be replaced rather than repaired?",
    answer: "A roof generally warrants replacement when it approaches 20–25 years of age, exhibits widespread granule loss exposing the underlying fiberglass mat, suffers systemic moisture intrusion across multiple structural decking sections, or has sustained severe catastrophic hail fractures over more than 30% of its surface plane.",
    category: "general"
  },
  {
    id: "faq-repairable",
    question: "Can storm-damaged or leaking roofs be repaired without total replacement?",
    answer: "Frequently, yes. If damage is localized—such as isolated wind-lifted shingles, degraded chimney step flashing, compromised pipe boots, or minor hail bruising in non-critical zones—precision targeted repair and localized underlayment restoration can stabilize the roof and extend its useful service life.",
    category: "services"
  },
  {
    id: "faq-inspections",
    question: "Do you provide comprehensive roofing inspections?",
    answer: "Yes. We offer non-invasive photographic and aerial drone inspections. Each audit yields an objective written report documenting decking stability, flashing integrity, ventilation dynamics, remaining anticipated lifespan, and prioritized repair recommendations without high-pressure sales.",
    category: "services"
  },
  {
    id: "faq-request-estimate",
    question: "How can I request a roofing estimate?",
    answer: "You can submit an estimate request directly through our online Quote Request Form on this website, or use the Request an Estimate button in the top navigation. Once received, our estimating team reviews property satellite imagery and coordinates a detailed on-site assessment at your convenience.",
    category: "estimates"
  },
  {
    id: "faq-service-area",
    question: "Which areas do you serve?",
    answer: "Our illustrative service footprint encompasses the greater Dallas metropolitan area and surrounding North Texas communities, including Highland Park, University Park, Plano, Frisco, Southlake, Richardson, McKinney, Fort Worth, Irving, Grapevine, and Carrollton.",
    category: "general"
  }
];
