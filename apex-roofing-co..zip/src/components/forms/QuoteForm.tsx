import React, { useState } from 'react';
import { submitEnquiry, StoredEnquiry } from '../../lib/enquiries';
import { QuoteFormData, validateQuoteForm, formatPhoneNumber } from '../../utils/validation';
import { CheckCircle2, AlertCircle, Loader2, ArrowRight, ShieldCheck } from 'lucide-react';

interface QuoteFormProps {
  initialService?: string;
  onSuccess?: (enquiry: StoredEnquiry) => void;
  isCompact?: boolean;
}

export const QuoteForm: React.FC<QuoteFormProps> = ({
  initialService = 'Roof Replacement',
  onSuccess,
  isCompact = false
}) => {
  const [formData, setFormData] = useState<QuoteFormData>({
    fullName: '',
    phone: '',
    email: '',
    propertyType: 'Residential',
    serviceNeeded: initialService,
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedEnquiry, setSubmittedEnquiry] = useState<StoredEnquiry | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value);
    setFormData(prev => ({ ...prev, phone: formatted }));
    if (errors.phone) setErrors(prev => ({ ...prev, phone: '' }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    // Validate fields
    const validation = validateQuoteForm(formData);
    if (!validation.isValid) {
      setErrors(validation.errors as Record<string, string>);
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await submitEnquiry(formData);
      if (result.success && result.enquiry) {
        setSubmittedEnquiry(result.enquiry);
        if (onSuccess) onSuccess(result.enquiry);
      } else {
        setSubmitError(result.error || "Submission failed. Please verify your details and retry.");
      }
    } catch {
      setSubmitError("Network connectivity interrupted. Please click to retry.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmittedEnquiry(null);
    setSubmitError(null);
    setFormData({
      fullName: '',
      phone: '',
      email: '',
      propertyType: 'Residential',
      serviceNeeded: 'Roof Replacement',
      message: ''
    });
    setErrors({});
  };

  if (submittedEnquiry) {
    return (
      <div className="bg-[#24282D] border border-white/10 rounded-sm p-6 md:p-8 text-center space-y-6 animate-fadeIn font-inter">
        <div className="w-14 h-14 rounded-full bg-[#F97316]/15 border border-[#F97316]/40 flex items-center justify-center mx-auto text-[#F97316]">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
            Estimate Request Confirmed
          </span>
          <h3 className="font-space text-2xl font-bold text-white">
            Thank you, {submittedEnquiry.fullName}
          </h3>
          <p className="text-sm text-[#A5A9AE] max-w-md mx-auto">
            Your project brief has been recorded. Our North Texas estimating team will analyze your property specifications and prepare a customized proposal.
          </p>
        </div>

        {/* Confirmation Details Card */}
        <div className="bg-[#17191C] border border-white/10 rounded-sm p-4 text-left max-w-md mx-auto space-y-2 text-xs">
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-[#A5A9AE]">Enquiry Reference:</span>
            <span className="font-mono text-white font-bold">{submittedEnquiry.referenceNumber}</span>
          </div>
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-[#A5A9AE]">Property Scope:</span>
            <span className="text-white">{submittedEnquiry.propertyType}</span>
          </div>
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-[#A5A9AE]">Service Needed:</span>
            <span className="text-white">{submittedEnquiry.serviceNeeded}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#A5A9AE]">Target Contact:</span>
            <span className="text-white">{submittedEnquiry.email}</span>
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={handleReset}
            type="button"
            className="text-xs font-semibold uppercase tracking-wider text-[#A5A9AE] hover:text-white transition-colors underline underline-offset-4"
          >
            Submit Another Project Estimate
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-[#24282D] border border-white/10 rounded-sm p-6 md:p-8 space-y-6 font-inter shadow-2xl">
      <div className="border-b border-white/10 pb-4">
        <span className="text-[11px] font-mono uppercase tracking-widest text-[#F97316] block mb-1">
          Dallas & North Texas Service
        </span>
        <h3 className="font-space text-2xl font-bold text-white">
          Request a Free Roofing Estimate
        </h3>
        <p className="text-xs text-[#A5A9AE] mt-1">
          Precision assessment with zero obligation. Completed within 24 hours.
        </p>
      </div>

      {submitError && (
        <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-sm flex items-start gap-3 text-xs text-red-200">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold">Unable to submit estimate</p>
            <p className="mt-0.5 text-red-300">{submitError}</p>
          </div>
        </div>
      )}

      {/* Row 1: Full Name & Phone */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="fullName" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
            Full Name <span className="text-[#F97316]">*</span>
          </label>
          <input
            id="fullName"
            name="fullName"
            type="text"
            required
            placeholder="e.g. Eleanor Vance"
            value={formData.fullName}
            onChange={handleChange}
            className={`w-full bg-[#17191C] border ${
              errors.fullName ? 'border-red-500' : 'border-white/10 focus:border-[#F97316]'
            } p-3 rounded-sm text-sm text-white placeholder-[#A5A9AE]/40 focus:outline-none transition-colors`}
          />
          {errors.fullName && (
            <p className="mt-1 text-[11px] text-red-400">{errors.fullName}</p>
          )}
        </div>

        <div>
          <label htmlFor="phone" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
            Phone Number <span className="text-[#F97316]">*</span>
          </label>
          <input
            id="phone"
            name="phone"
            type="tel"
            required
            placeholder="(214) 555-0199"
            value={formData.phone}
            onChange={handlePhoneChange}
            className={`w-full bg-[#17191C] border ${
              errors.phone ? 'border-red-500' : 'border-white/10 focus:border-[#F97316]'
            } p-3 rounded-sm text-sm text-white placeholder-[#A5A9AE]/40 focus:outline-none transition-colors font-mono`}
          />
          {errors.phone && (
            <p className="mt-1 text-[11px] text-red-400">{errors.phone}</p>
          )}
        </div>
      </div>

      {/* Row 2: Email Address */}
      <div>
        <label htmlFor="email" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
          Email Address <span className="text-[#F97316]">*</span>
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          placeholder="eleanor@example.com"
          value={formData.email}
          onChange={handleChange}
          className={`w-full bg-[#17191C] border ${
            errors.email ? 'border-red-500' : 'border-white/10 focus:border-[#F97316]'
          } p-3 rounded-sm text-sm text-white placeholder-[#A5A9AE]/40 focus:outline-none transition-colors`}
        />
        {errors.email && (
          <p className="mt-1 text-[11px] text-red-400">{errors.email}</p>
        )}
      </div>

      {/* Row 3: Property Type & Service Needed */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="propertyType" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
            Property Type <span className="text-[#F97316]">*</span>
          </label>
          <select
            id="propertyType"
            name="propertyType"
            value={formData.propertyType}
            onChange={handleChange}
            className="w-full bg-[#17191C] border border-white/10 focus:border-[#F97316] p-3 rounded-sm text-sm text-white focus:outline-none transition-colors"
          >
            <option value="Residential">Residential Property</option>
            <option value="Commercial">Commercial / Industrial Property</option>
          </select>
        </div>

        <div>
          <label htmlFor="serviceNeeded" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
            Service Needed <span className="text-[#F97316]">*</span>
          </label>
          <select
            id="serviceNeeded"
            name="serviceNeeded"
            value={formData.serviceNeeded}
            onChange={handleChange}
            className="w-full bg-[#17191C] border border-white/10 focus:border-[#F97316] p-3 rounded-sm text-sm text-white focus:outline-none transition-colors"
          >
            <option value="Roof Replacement">Roof Replacement</option>
            <option value="Roof Repair">Roof Repair</option>
            <option value="New Roof Installation">New Roof Installation</option>
            <option value="Commercial Roofing">Commercial Roofing (TPO/PVC)</option>
            <option value="Roof Inspection">Roof Inspection & Audit</option>
            <option value="Storm Damage Restoration">Storm Damage Restoration</option>
            <option value="Roofing Maintenance">Roofing Maintenance</option>
            <option value="Other">Other Architectural Specialty</option>
          </select>
        </div>
      </div>

      {/* Row 4: Project Message */}
      <div>
        <label htmlFor="message" className="block text-xs uppercase tracking-wider text-[#A5A9AE] mb-1.5 font-medium">
          Project Details / Location Context <span className="text-[#F97316]">*</span>
        </label>
        <textarea
          id="message"
          name="message"
          rows={isCompact ? 3 : 4}
          required
          placeholder="Briefly describe your roof condition, material preferences (standing seam metal, shingle, tile), and property location in Dallas..."
          value={formData.message}
          onChange={handleChange}
          className={`w-full bg-[#17191C] border ${
            errors.message ? 'border-red-500' : 'border-white/10 focus:border-[#F97316]'
          } p-3 rounded-sm text-sm text-white placeholder-[#A5A9AE]/40 focus:outline-none transition-colors resize-none`}
        />
        {errors.message && (
          <p className="mt-1 text-[11px] text-red-400">{errors.message}</p>
        )}
      </div>

      <div className="space-y-3">
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-[#F97316] hover:bg-[#EA580C] disabled:bg-[#F97316]/50 text-white py-4 px-6 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-[#F97316]/20 active:scale-[0.99] cursor-pointer disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Transmitting Estimate Request...</span>
            </>
          ) : (
            <>
              <span>Request Free Roofing Estimate</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        <div className="flex items-center justify-center gap-2 text-[11px] text-[#A5A9AE]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#F97316]" />
          <span>Zero spam guarantee · Your contact info is strictly protected</span>
        </div>
      </div>
    </form>
  );
};
