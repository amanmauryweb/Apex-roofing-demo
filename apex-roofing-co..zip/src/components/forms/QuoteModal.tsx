import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { QuoteForm } from './QuoteForm';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultService?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({ isOpen, onClose, defaultService }) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#17191C]/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-label="Request a Free Roofing Estimate Modal"
    >
      <div className="relative w-full max-w-2xl bg-[#24282D] rounded-sm shadow-2xl border border-white/10 my-8">
        <button
          onClick={onClose}
          type="button"
          className="absolute top-4 right-4 z-10 p-2 text-[#A5A9AE] hover:text-white rounded-sm border border-white/10 hover:border-white/30 transition-colors"
          aria-label="Close Estimate Modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-2 sm:p-4">
          <QuoteForm
            initialService={defaultService || 'Roof Replacement'}
            isCompact={true}
            onSuccess={() => {
              // User sees confirmation inside form
            }}
          />
        </div>
      </div>
    </div>
  );
};
