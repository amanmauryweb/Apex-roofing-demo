import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Phone, Calendar } from 'lucide-react';
import { BUSINESS_CONFIG } from '../../config/business';

interface FloatingCTAProps {
  onOpenQuoteModal: () => void;
}

export const FloatingCTA: React.FC<FloatingCTAProps> = ({ onOpenQuoteModal }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show floating CTA once user scrolls past the hero section (> 400px)
      setIsVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <>
      {/* Desktop Floating Estimate Button (bottom-right) */}
      <div className="hidden md:block fixed bottom-8 right-8 z-30">
        <button
          onClick={onOpenQuoteModal}
          type="button"
          className="group flex items-center gap-3 bg-[#17191C]/95 hover:bg-[#24282D] text-white border border-white/15 hover:border-[#F97316] px-5 py-3 rounded-full shadow-2xl backdrop-blur-md transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316]"
          aria-label="Request a Free Roofing Estimate"
        >
          <div className="w-2.5 h-2.5 rounded-full bg-[#F97316] animate-pulse" />
          <span className="text-xs font-semibold uppercase tracking-wider font-inter">
            Request an Estimate
          </span>
          <div className="w-6 h-6 rounded-full bg-[#F97316] flex items-center justify-center text-white transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </button>
      </div>

      {/* Mobile Fixed Bottom CTA Bar (max 15% height, clean, uncrowded) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#17191C]/96 backdrop-blur-lg border-t border-white/10 px-4 py-2.5 shadow-2xl flex items-center gap-3">
        {BUSINESS_CONFIG.isLiveContactActive ? (
          <a
            href={`tel:${BUSINESS_CONFIG.phonePlaceholder.replace(/\D/g, '')}`}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-[#24282D] text-white text-xs font-semibold uppercase tracking-wider rounded-sm border border-white/10 active:bg-white/10"
          >
            <Phone className="w-3.5 h-3.5 text-[#F97316]" />
            <span>Call Apex</span>
          </a>
        ) : (
          <div className="flex-1 flex items-center justify-center gap-1.5 py-2 text-[11px] text-[#A5A9AE] border border-white/5 rounded-sm">
            <span className="text-[#F97316]">Dallas, TX</span>
            <span>·</span>
            <span>Est. Quotes</span>
          </div>
        )}

        <button
          onClick={onOpenQuoteModal}
          type="button"
          className="flex-[2] flex items-center justify-center gap-2 py-2.5 bg-[#F97316] hover:bg-[#EA580C] text-white text-xs font-bold uppercase tracking-wider rounded-sm shadow-md active:scale-[0.98]"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Request Estimate</span>
        </button>
      </div>
    </>
  );
};
