import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ArrowUpRight, ClipboardList } from 'lucide-react';
import { BUSINESS_CONFIG } from '../../config/business';
import { getStoredEnquiries } from '../../lib/enquiries';

interface NavbarProps {
  onOpenQuoteModal: () => void;
  onOpenEnquiriesDrawer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenQuoteModal, onOpenEnquiriesDrawer }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [enquiryCount, setEnquiryCount] = useState(0);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const updateCount = () => {
      setEnquiryCount(getStoredEnquiries().length);
    };
    updateCount();
    window.addEventListener('apex:enquiry-submitted', updateCount);
    window.addEventListener('apex:enquiry-updated', updateCount);
    return () => {
      window.removeEventListener('apex:enquiry-submitted', updateCount);
      window.removeEventListener('apex:enquiry-updated', updateCount);
    };
  }, []);

  // Close mobile drawer upon route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Services', path: '/services' },
    { label: 'Projects', path: '/projects' },
    { label: 'Reviews', path: '/reviews' },
    { label: 'Contact', path: '/contact' }
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? 'bg-[#17191C]/92 backdrop-blur-md border-b border-white/10 py-3.5 shadow-2xl shadow-black/40'
            : 'bg-transparent py-5 border-b border-white/5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element Brand Wordmark */}
          <Link
            to="/"
            className="flex items-center gap-3 text-white group whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316]"
            aria-label="Apex Roofing Co. Home"
          >
            <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center font-space font-bold text-white text-base tracking-wider shadow-sm transition-transform duration-200 group-hover:scale-105">
              ▲
            </div>
            <div className="flex flex-col">
              <span className="font-space text-lg font-bold tracking-tight text-white uppercase leading-none">
                {BUSINESS_CONFIG.shortName}
              </span>
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#A5A9AE] mt-0.5 font-inter">
                Dallas, TX
              </span>
            </div>
          </Link>

          {/* Zone 2: Clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium font-inter">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-200 text-sm ${
                    isActive
                      ? 'text-white font-semibold'
                      : 'text-[#A5A9AE] hover:text-white'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#F97316] rounded-full" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Demo Enquiries Inspector Trigger */}
            <button
              onClick={onOpenEnquiriesDrawer}
              type="button"
              className="hidden md:flex items-center gap-2 px-3 py-2 text-xs font-medium text-[#A5A9AE] hover:text-white border border-white/10 hover:border-white/20 rounded-sm transition-colors whitespace-nowrap"
              title="View test submissions stored in demonstrator database"
            >
              <ClipboardList className="w-3.5 h-3.5 text-[#F97316]" />
              <span>Enquiries</span>
              {enquiryCount > 0 && (
                <span className="px-1.5 py-0.2 bg-[#F97316]/20 text-[#F97316] text-[10px] font-mono rounded">
                  {enquiryCount}
                </span>
              )}
            </button>

            {/* Primary Action Button - visible on sm and up */}
            <button
              onClick={onOpenQuoteModal}
              type="button"
              className="hidden sm:inline-flex items-center gap-2 bg-[#F97316] hover:bg-[#EA580C] text-white px-4 lg:px-5 py-2.5 rounded-sm text-xs font-semibold uppercase tracking-wider font-inter transition-all duration-200 shadow-md shadow-[#F97316]/20 hover:shadow-lg hover:shadow-[#F97316]/30 active:scale-[0.98] whitespace-nowrap shrink-0"
            >
              <span>Request Estimate</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="lg:hidden p-2 text-[#A5A9AE] hover:text-white border border-white/10 rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316] flex items-center justify-center"
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5 text-white" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-[65px] z-30 bg-[#17191C]/98 backdrop-blur-xl border-t border-white/10 p-6 flex flex-col justify-between overflow-y-auto lg:hidden">
          <div className="space-y-4 pt-2">
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#A5A9AE] block mb-2">
              Navigation
            </span>
            {navLinks.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`block py-3 text-xl font-space font-medium border-b border-white/5 transition-colors ${
                    isActive ? 'text-[#F97316] font-bold' : 'text-white hover:text-[#F97316]'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </div>

          <div className="pt-6 border-t border-white/10 space-y-4">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenEnquiriesDrawer();
              }}
              type="button"
              className="w-full flex items-center justify-center gap-2 py-3 border border-white/15 text-sm text-[#A5A9AE] hover:text-white rounded-sm"
            >
              <ClipboardList className="w-4 h-4 text-[#F97316]" />
              <span>View Submitted Enquiries ({enquiryCount})</span>
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuoteModal();
              }}
              type="button"
              className="w-full bg-[#F97316] hover:bg-[#EA580C] text-white py-3.5 text-center text-xs font-bold uppercase tracking-wider rounded-sm shadow-lg shadow-[#F97316]/20"
            >
              Request Free Estimate
            </button>

            <p className="text-[11px] text-[#A5A9AE] text-center leading-relaxed">
              Serving Dallas, Highland Park, Plano, Frisco & surrounding communities.
            </p>
          </div>
        </div>
      )}
    </>
  );
};
