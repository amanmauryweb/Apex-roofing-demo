import React from 'react';
import { Link } from 'react-router-dom';
import { BUSINESS_CONFIG } from '../../config/business';
import { SERVICES_DATA } from '../../data/services';
import { Phone, Mail, MapPin, ExternalLink, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onOpenQuoteModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenQuoteModal }) => {
  return (
    <footer className="bg-[#111315] text-[#A5A9AE] border-t border-white/10 pt-20 pb-12 font-inter">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Col 1 & 2: Brand & Philosophy */}
          <div className="lg:col-span-2 space-y-6">
            <Link to="/" className="inline-flex items-center gap-3 text-white">
              <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center font-space font-bold text-white text-base">
                ▲
              </div>
              <span className="font-space text-xl font-bold tracking-tight text-white uppercase">
                {BUSINESS_CONFIG.name}
              </span>
            </Link>

            <p className="text-sm leading-relaxed text-[#A5A9AE] max-w-sm">
              An architectural roofing contractor combining high-durability engineering with clean geometric lines. Dedicated to protecting North Texas residential estates and commercial assets.
            </p>

            <div className="p-4 bg-[#17191C] border border-white/10 rounded-sm space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-white">
                <ShieldCheck className="w-4 h-4 text-[#F97316]" />
                <span>Demonstration Portfolio Project</span>
              </div>
              <p className="text-[11px] text-[#A5A9AE] leading-relaxed">
                {BUSINESS_CONFIG.disclaimer}
              </p>
            </div>
          </div>

          {/* Col 3: Navigation */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-[0.2em] text-white font-semibold mb-6">
              Navigation
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/" className="hover:text-[#F97316] transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-[#F97316] transition-colors">About Our Craft</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-[#F97316] transition-colors">Roofing Services</Link>
              </li>
              <li>
                <Link to="/projects" className="hover:text-[#F97316] transition-colors">Architectural Portfolio</Link>
              </li>
              <li>
                <Link to="/reviews" className="hover:text-[#F97316] transition-colors">Client Reviews (Demo)</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#F97316] transition-colors">Contact & Location</Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Services */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-[0.2em] text-white font-semibold mb-6">
              Core Solutions
            </h4>
            <ul className="space-y-3 text-sm">
              {SERVICES_DATA.slice(0, 6).map((srv) => (
                <li key={srv.id}>
                  <Link
                    to={`/services#${srv.id}`}
                    className="hover:text-[#F97316] transition-colors block truncate"
                  >
                    {srv.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 5: Contact Placeholders & Coverage */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-[0.2em] text-white font-semibold mb-6">
              Contact & Coverage
            </h4>
            <div className="space-y-4 text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white font-medium text-xs">Primary Metro</span>
                  <span className="text-xs text-[#A5A9AE]">{BUSINESS_CONFIG.location}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white font-medium text-xs">Telephone (Placeholder)</span>
                  <span className="text-xs text-[#A5A9AE] font-mono">{BUSINESS_CONFIG.phonePlaceholder}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white font-medium text-xs">Email (Placeholder)</span>
                  <span className="text-xs text-[#A5A9AE]">{BUSINESS_CONFIG.emailPlaceholder}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenQuoteModal}
                  type="button"
                  className="w-full bg-[#24282D] hover:bg-[#F97316] hover:text-white text-xs font-semibold uppercase tracking-wider py-2.5 px-3 border border-white/10 rounded-sm transition-colors text-white text-center"
                >
                  Request Free Estimate
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Coverage Cities Ticker */}
        <div className="py-6 border-y border-white/5 mb-8">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2 text-xs">
            <span className="text-white font-medium">Service Coverage:</span>
            {BUSINESS_CONFIG.coverageCities.map((city, idx) => (
              <React.Fragment key={city}>
                <span className="text-[#A5A9AE]">{city}</span>
                {idx < BUSINESS_CONFIG.coverageCities.length - 1 && (
                  <span className="text-white/20">·</span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Bottom Strip */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-[#A5A9AE]">
          <p>© {new Date().getFullYear()} {BUSINESS_CONFIG.name}. All rights reserved.</p>

          <div className="flex flex-wrap items-center gap-6">
            <Link to="/about" className="hover:text-white transition-colors">Terms of Service</Link>
            <span className="text-white/20">·</span>
            <Link to="/about" className="hover:text-white transition-colors">Privacy Policy</Link>
            <span className="text-white/20">·</span>
            <span className="text-[#A5A9AE]/60">Placeholder Social Links:</span>
            {BUSINESS_CONFIG.socials.map((s) => (
              <span
                key={s.name}
                className="text-[#A5A9AE]/80 hover:text-white cursor-pointer inline-flex items-center gap-1"
                title="Illustrative social link placeholder"
              >
                {s.name}
                <ExternalLink className="w-2.5 h-2.5 opacity-60" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};
