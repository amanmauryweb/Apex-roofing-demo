import React, { useState, useEffect } from 'react';
import { X, Trash2, Calendar, Phone, Mail, Building2, Layers, CheckCircle2, RefreshCw } from 'lucide-react';
import { getStoredEnquiries, deleteStoredEnquiry, clearAllEnquiries, StoredEnquiry, submitEnquiry } from '../../lib/enquiries';

interface EnquiriesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenQuoteModal: () => void;
}

export const EnquiriesDrawer: React.FC<EnquiriesDrawerProps> = ({ isOpen, onClose, onOpenQuoteModal }) => {
  const [enquiries, setEnquiries] = useState<StoredEnquiry[]>([]);

  const loadEnquiries = () => {
    setEnquiries(getStoredEnquiries());
  };

  useEffect(() => {
    loadEnquiries();
    const handleUpdate = () => loadEnquiries();
    window.addEventListener('apex:enquiry-submitted', handleUpdate);
    window.addEventListener('apex:enquiry-updated', handleUpdate);
    return () => {
      window.removeEventListener('apex:enquiry-submitted', handleUpdate);
      window.removeEventListener('apex:enquiry-updated', handleUpdate);
    };
  }, [isOpen]);

  const handleDelete = (id: string) => {
    const updated = deleteStoredEnquiry(id);
    setEnquiries(updated);
  };

  const handleClear = () => {
    if (window.confirm("Clear all demonstrator quote enquiries from storage?")) {
      clearAllEnquiries();
      setEnquiries([]);
    }
  };

  const handleSeedSample = async () => {
    await submitEnquiry({
      fullName: "Marcus Sterling",
      phone: "(214) 555-4921",
      email: "m.sterling@example.com",
      propertyType: "Residential",
      serviceNeeded: "Roof Replacement",
      message: "Modern residential estate in Preston Hollow needing full standing seam metal replacement."
    });
    loadEnquiries();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#17191C]/80 backdrop-blur-sm flex justify-end animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-label="Submitted Enquiries Inspector"
    >
      <div className="w-full max-w-lg bg-[#1D2024] border-l border-white/10 h-full flex flex-col justify-between shadow-2xl">
        {/* Drawer Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F97316]" />
              <h3 className="font-space text-lg font-bold text-white uppercase tracking-tight">
                Enquiries Inspector
              </h3>
            </div>
            <p className="text-xs text-[#A5A9AE] mt-0.5">
              Demonstration database store ({enquiries.length} records)
            </p>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="p-2 text-[#A5A9AE] hover:text-white rounded-sm border border-white/10"
            aria-label="Close Enquiries Drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Enquiries */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {enquiries.length === 0 ? (
            <div className="py-16 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#A5A9AE]">
                <Layers className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="font-space text-base text-white">No Enquiries Yet</p>
                <p className="text-xs text-[#A5A9AE] max-w-xs mx-auto">
                  Submit an estimate request from the website form to verify the submission workflow and database persistence.
                </p>
              </div>
              <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
                <button
                  onClick={handleSeedSample}
                  type="button"
                  className="px-4 py-2 bg-[#24282D] hover:bg-white/10 text-white text-xs uppercase tracking-wider rounded-sm border border-white/10 transition-colors"
                >
                  Insert Sample Enquiry
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenQuoteModal();
                  }}
                  type="button"
                  className="px-4 py-2 bg-[#F97316] hover:bg-[#EA580C] text-white text-xs uppercase tracking-wider font-semibold rounded-sm transition-colors"
                >
                  Open Quote Form
                </button>
              </div>
            </div>
          ) : (
            enquiries.map((enq) => (
              <div
                key={enq.id}
                className="bg-[#24282D] border border-white/10 rounded-sm p-4 space-y-3 font-inter hover:border-white/20 transition-colors"
              >
                <div className="flex items-start justify-between gap-2 border-b border-white/5 pb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white font-space">
                        {enq.fullName}
                      </h4>
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-[#F97316]/20 text-[#F97316] rounded">
                        {enq.referenceNumber}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#A5A9AE]">
                      {new Date(enq.createdAt).toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => handleDelete(enq.id)}
                    type="button"
                    className="p-1.5 text-[#A5A9AE] hover:text-red-400 transition-colors rounded"
                    title="Delete record"
                    aria-label={`Delete enquiry ${enq.referenceNumber}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1.5 text-[#A5A9AE]">
                    <Building2 className="w-3.5 h-3.5 text-[#F97316]" />
                    <span>{enq.propertyType}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#A5A9AE]">
                    <Layers className="w-3.5 h-3.5 text-[#F97316]" />
                    <span className="truncate">{enq.serviceNeeded}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#A5A9AE]">
                    <Phone className="w-3.5 h-3.5 text-[#F97316]" />
                    <span className="font-mono">{enq.phone}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#A5A9AE]">
                    <Mail className="w-3.5 h-3.5 text-[#F97316]" />
                    <span className="truncate">{enq.email}</span>
                  </div>
                </div>

                <div className="bg-[#17191C] p-2.5 rounded-sm text-xs text-white/90 leading-relaxed border border-white/5">
                  <p className="text-[10px] uppercase font-mono text-[#A5A9AE] mb-1">Project Note:</p>
                  "{enq.message}"
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#A5A9AE] pt-1">
                  <span className="inline-flex items-center gap-1 text-emerald-400">
                    <CheckCircle2 className="w-3 h-3" />
                    Status: {enq.status}
                  </span>
                  <span className="font-mono text-[10px] text-[#A5A9AE]/60">
                    Target: {enq.storageTarget}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-4 border-t border-white/10 bg-[#17191C] flex items-center justify-between gap-3">
          {enquiries.length > 0 ? (
            <button
              onClick={handleClear}
              type="button"
              className="text-xs text-red-400 hover:text-red-300 underline font-mono"
            >
              Clear All Records
            </button>
          ) : (
            <span className="text-[11px] text-[#A5A9AE]">Records synced locally</span>
          )}

          <button
            onClick={() => {
              onClose();
              onOpenQuoteModal();
            }}
            type="button"
            className="px-4 py-2 bg-[#F97316] hover:bg-[#EA580C] text-white text-xs font-bold uppercase tracking-wider rounded-sm transition-colors"
          >
            New Estimate
          </button>
        </div>
      </div>
    </div>
  );
};
