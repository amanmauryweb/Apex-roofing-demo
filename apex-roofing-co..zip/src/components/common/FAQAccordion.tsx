import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQItem } from '../../data/faq';

interface FAQAccordionProps {
  items: FAQItem[];
}

export const FAQAccordion: React.FC<FAQAccordionProps> = ({ items }) => {
  const [openId, setOpenId] = useState<string | null>(items[0]?.id || null);

  const toggleItem = (id: string) => {
    setOpenId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-3 font-inter">
      {items.map((item, index) => {
        const isOpen = openId === item.id;
        return (
          <div
            key={item.id}
            className={`border rounded-sm transition-all duration-200 overflow-hidden ${
              isOpen
                ? 'bg-[#24282D] border-white/20 shadow-lg'
                : 'bg-[#1D2024] border-white/5 hover:border-white/10'
            }`}
          >
            <button
              onClick={() => toggleItem(item.id)}
              type="button"
              className="w-full text-left p-5 md:p-6 flex items-center justify-between gap-4 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316]"
              aria-expanded={isOpen}
              aria-controls={`faq-answer-${item.id}`}
              id={`faq-question-${item.id}`}
            >
              <div className="flex items-center gap-4">
                <span className="text-xs font-mono text-[#F97316] font-bold">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <span className="font-space text-base md:text-lg font-bold text-white tracking-tight">
                  {item.question}
                </span>
              </div>
              <div
                className={`w-7 h-7 rounded-sm flex items-center justify-center shrink-0 transition-transform duration-200 border border-white/10 ${
                  isOpen ? 'rotate-180 bg-[#F97316] text-white border-transparent' : 'text-[#A5A9AE] bg-[#17191C]'
                }`}
              >
                <ChevronDown className="w-4 h-4" />
              </div>
            </button>

            {isOpen && (
              <div
                id={`faq-answer-${item.id}`}
                role="region"
                aria-labelledby={`faq-question-${item.id}`}
                className="px-5 md:px-6 pb-6 pt-1 text-sm leading-relaxed text-[#A5A9AE] border-t border-white/5 animate-fadeIn"
              >
                <p>{item.answer}</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
