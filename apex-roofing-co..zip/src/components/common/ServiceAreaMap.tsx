import React, { useState } from 'react';
import { MapPin, Navigation, CheckCircle, Shield } from 'lucide-react';
import { BUSINESS_CONFIG } from '../../config/business';

export const ServiceAreaMap: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>("Dallas");

  const regions = [
    { name: "Dallas (Central & Uptown)", type: "Core Urban Metro", response: "Priority Same-Day Diagnostics" },
    { name: "Highland Park & University Park", type: "Residential Estates", response: "Architectural Slate & Metal Specialization" },
    { name: "Plano & Richardson", type: "North Corridor", response: "Residential & Commercial Low-Slope" },
    { name: "Frisco & McKinney", type: "Expanding North Metro", response: "New Construction & Storm Restoration" },
    { name: "Southlake & Grapevine", type: "West Metro & Cross Timbers", response: "Custom Designer Shingle & Metal" },
    { name: "Fort Worth & Arlington", type: "Tarrant County", response: "Scheduled Commercial & Residential Projects" }
  ];

  return (
    <div className="bg-[#24282D] border border-white/10 rounded-sm p-6 lg:p-10 font-inter">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left: Interactive Region Selection */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
              Coverage Radius
            </span>
            <h3 className="font-space text-2xl md:text-3xl font-bold text-white leading-tight">
              Serving Dallas and Surrounding Communities.
            </h3>
            <p className="text-xs text-[#A5A9AE] leading-relaxed">
              Illustrative service footprint spanning the greater DFW metropolitan area. Select a municipal sector to view response capabilities:
            </p>
          </div>

          <div className="space-y-2">
            {regions.map((reg) => {
              const isSelected = selectedCity === reg.name;
              return (
                <button
                  key={reg.name}
                  onClick={() => setSelectedCity(reg.name)}
                  type="button"
                  className={`w-full text-left p-3 rounded-sm border transition-all text-xs flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#17191C] border-[#F97316] text-white shadow-md'
                      : 'bg-[#17191C]/60 border-white/5 text-[#A5A9AE] hover:text-white hover:border-white/15'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-[#F97316]' : 'text-[#A5A9AE]'}`} />
                    <span className="font-medium">{reg.name}</span>
                  </div>
                  <span className="text-[10px] font-mono opacity-60 uppercase">{reg.type}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 flex items-center gap-2 text-xs text-[#A5A9AE]">
            <Shield className="w-4 h-4 text-[#F97316] shrink-0" />
            <span>Fully insured project staging across all municipalities</span>
          </div>
        </div>

        {/* Right: Architectural Vector Topology Illustration */}
        <div className="lg:col-span-7 bg-[#17191C] border border-white/10 rounded-sm p-6 relative overflow-hidden aspect-[4/3] flex flex-col justify-between shadow-inner">
          {/* Subtle grid lines background */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
              backgroundSize: '40px 40px'
            }}
          />

          {/* Concentric service rings around Dallas center */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full border border-dashed border-[#F97316]/20 pointer-events-none" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 h-56 rounded-full border border-white/10 pointer-events-none" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-[#F97316]/30 bg-[#F97316]/5 pointer-events-none" />

          {/* Map Header */}
          <div className="relative z-10 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-[#F97316]" />
              <span className="font-space uppercase tracking-wider text-white font-bold">
                North Texas Metroplex Grid
              </span>
            </div>
            <span className="text-[11px] font-mono text-[#A5A9AE]">
              32.7767° N · 96.7970° W
            </span>
          </div>

          {/* Central Architectural Hub Indicator */}
          <div className="relative z-10 my-auto text-center space-y-3 py-6">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#17191C] border-2 border-[#F97316] text-[#F97316] shadow-xl mx-auto animate-pulse">
              ▲
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#F97316] block">
                Regional Headquarters
              </span>
              <h4 className="font-space text-xl font-bold text-white mt-0.5">
                Dallas Metro Operations Center
              </h4>
              <p className="text-xs text-[#A5A9AE] max-w-sm mx-auto mt-1">
                Active service fleet dispatched daily across Dallas, Collin, Denton, and Tarrant Counties.
              </p>
            </div>
          </div>

          {/* City Nodes Grid */}
          <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-2 pt-4 border-t border-white/10 text-center">
            {['Highland Park', 'Plano', 'Frisco', 'Fort Worth'].map((node) => (
              <div key={node} className="bg-[#24282D]/80 border border-white/5 py-1.5 px-2 rounded-sm">
                <span className="text-[10px] text-white font-medium block truncate">{node}</span>
                <span className="text-[9px] text-emerald-400 font-mono">● Active Crew</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
