import React, { useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, MapPin, Layers } from 'lucide-react';
import { ProjectItem } from '../../data/projects';

interface ImageLightboxProps {
  projects: ProjectItem[];
  currentIndex: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
  onOpenQuoteModal: () => void;
}

export const ImageLightbox: React.FC<ImageLightboxProps> = ({
  projects,
  currentIndex,
  onClose,
  onNavigate,
  onOpenQuoteModal
}) => {
  const isOpen = currentIndex !== null && currentIndex >= 0 && currentIndex < projects.length;
  const project = isOpen ? projects[currentIndex] : null;

  const handleNext = useCallback(() => {
    if (currentIndex !== null) {
      onNavigate((currentIndex + 1) % projects.length);
    }
  }, [currentIndex, projects.length, onNavigate]);

  const handlePrev = useCallback(() => {
    if (currentIndex !== null) {
      onNavigate((currentIndex - 1 + projects.length) % projects.length);
    }
  }, [currentIndex, projects.length, onNavigate]);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    // Lock body scroll
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, handleNext, handlePrev, onClose]);

  if (!isOpen || !project) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#17191C]/96 backdrop-blur-md flex flex-col justify-between p-4 md:p-8 animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-label="Image Lightbox Viewer"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between text-white pb-4 border-b border-white/10">
        <div className="flex items-center gap-4">
          <span className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
            Project {currentIndex + 1} of {projects.length}
          </span>
          <span className="hidden sm:inline-block text-white/20">|</span>
          <span className="hidden sm:inline-block text-xs text-[#A5A9AE] uppercase tracking-wider font-inter">
            {project.category} · {project.roofType}
          </span>
        </div>

        <button
          onClick={onClose}
          type="button"
          className="p-2 text-[#A5A9AE] hover:text-white border border-white/10 hover:border-white/30 rounded-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316]"
          aria-label="Close Lightbox (Esc)"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Image Container with Nav Arrows */}
      <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden">
        {/* Left Arrow */}
        <button
          onClick={handlePrev}
          type="button"
          className="absolute left-2 md:left-6 z-10 p-3 bg-[#17191C]/80 hover:bg-[#F97316] text-white rounded-full border border-white/15 transition-all shadow-xl active:scale-95"
          aria-label="Previous Project (Left Arrow)"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Center Photograph */}
        <div className="max-h-[68vh] max-w-5xl w-full flex items-center justify-center">
          <img
            src={project.image}
            alt={project.title}
            referrerPolicy="no-referrer"
            className="max-h-[68vh] w-auto max-w-full object-contain rounded-sm shadow-2xl border border-white/10"
          />
        </div>

        {/* Right Arrow */}
        <button
          onClick={handleNext}
          type="button"
          className="absolute right-2 md:right-6 z-10 p-3 bg-[#17191C]/80 hover:bg-[#F97316] text-white rounded-full border border-white/15 transition-all shadow-xl active:scale-95"
          aria-label="Next Project (Right Arrow)"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Bottom Architectural Info Strip */}
      <div className="bg-[#24282D]/90 border border-white/10 rounded-sm p-4 md:p-6 max-w-5xl mx-auto w-full flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h3 className="font-space text-lg font-bold text-white">
              {project.title}
            </h3>
            <span className="text-[10px] font-mono uppercase bg-[#17191C] px-2 py-0.5 rounded text-[#A5A9AE] border border-white/10">
              Demo Portfolio Case
            </span>
          </div>
          <p className="text-xs text-[#A5A9AE] line-clamp-2 max-w-2xl">
            {project.summary}
          </p>
          <div className="flex items-center gap-4 text-[11px] text-[#A5A9AE] mt-2">
            <span className="inline-flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#F97316]" />
              {project.location}
            </span>
            <span>·</span>
            <span className="inline-flex items-center gap-1">
              <Layers className="w-3 h-3 text-[#F97316]" />
              {project.roofType}
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            onClose();
            onOpenQuoteModal();
          }}
          type="button"
          className="bg-[#F97316] hover:bg-[#EA580C] text-white px-5 py-2.5 rounded-sm text-xs font-semibold uppercase tracking-wider whitespace-nowrap shrink-0 transition-colors"
        >
          Request Similar Roof
        </button>
      </div>
    </div>
  );
};
