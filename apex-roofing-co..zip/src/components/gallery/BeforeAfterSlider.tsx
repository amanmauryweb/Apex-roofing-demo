import React, { useState, useRef, useCallback } from 'react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  caption?: string;
  initialPosition?: number;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = "Original Substrate & Weathering",
  afterLabel = "Restored Standing Seam & Shingle",
  caption = "Interactive demonstration comparison: Slide left or right to inspect structural transformation.",
  initialPosition = 50
}) => {
  const [sliderPosition, setSliderPosition] = useState(initialPosition);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  }, []);

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    updatePosition(e.clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      updatePosition(e.touches[0].clientX);
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    updatePosition(e.clientX);
  };

  return (
    <div className="w-full">
      <div
        ref={containerRef}
        onClick={handleClick}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
        className="relative w-full aspect-[16/9] md:aspect-[21/9] bg-[#24282D] rounded-sm overflow-hidden select-none cursor-ew-resize border border-white/10 shadow-2xl group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F97316]"
        tabIndex={0}
        role="slider"
        aria-label="Before and after roofing comparison slider"
        aria-valuenow={Math.round(sliderPosition)}
        aria-valuemin={0}
        aria-valuemax={100}
        onKeyDown={(e) => {
          if (e.key === 'ArrowLeft') setSliderPosition(p => Math.max(0, p - 5));
          if (e.key === 'ArrowRight') setSliderPosition(p => Math.min(100, p + 5));
        }}
      >
        {/* AFTER Image (Full container underneath) */}
        <img
          src={afterImage}
          alt="Restored roof after installation"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        />

        {/* BEFORE Image (Clipped overlay on top) */}
        <div
          className="absolute inset-0 overflow-hidden pointer-events-none"
          style={{ width: `${sliderPosition}%` }}
        >
          <img
            src={beforeImage}
            alt="Roof condition before restoration"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover pointer-events-none filter brightness-95"
            style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100vw', maxWidth: 'none' }}
          />
        </div>

        {/* Vertical Divider Line */}
        <div
          className="absolute top-0 bottom-0 w-[2px] bg-white pointer-events-none transform -translate-x-1/2 z-10"
          style={{ left: `${sliderPosition}%` }}
        >
          {/* Draggable Circle Handle */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-[#17191C] border-2 border-[#F97316] shadow-xl flex items-center justify-center text-white transition-transform group-hover:scale-110">
            <div className="flex items-center gap-1 text-[10px] font-mono tracking-tighter">
              <span>◀</span>
              <span>▶</span>
            </div>
          </div>
        </div>

        {/* Before Badge */}
        <div className="absolute bottom-4 left-4 z-20 pointer-events-none bg-[#17191C]/85 backdrop-blur-md px-3 py-1.5 rounded-sm border border-white/10 text-[11px] font-space uppercase tracking-wider text-white">
          <span className="text-[#A5A9AE] mr-1.5 font-inter">Phase:</span>
          <span>{beforeLabel}</span>
        </div>

        {/* After Badge */}
        <div className="absolute bottom-4 right-4 z-20 pointer-events-none bg-[#17191C]/85 backdrop-blur-md px-3 py-1.5 rounded-sm border border-[#F97316]/30 text-[11px] font-space uppercase tracking-wider text-white">
          <span className="text-[#F97316] mr-1.5 font-inter">Restored:</span>
          <span>{afterLabel}</span>
        </div>
      </div>

      {/* Caption & Accessibility prompt */}
      <div className="mt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-[#A5A9AE]">
        <p>{caption}</p>
        <span className="text-[11px] font-mono text-[#A5A9AE]/80">
          Position: {Math.round(sliderPosition)}% (Use mouse drag, swipe, or Arrow Keys)
        </span>
      </div>
    </div>
  );
};
