import { QuoteFormData, validateQuoteForm } from '../utils/validation';

export interface StoredEnquiry extends QuoteFormData {
  id: string;
  referenceNumber: string;
  status: 'new' | 'reviewed' | 'scheduled';
  createdAt: string;
  storageTarget: 'supabase' | 'local_demo_store';
}

const STORAGE_KEY = 'apex_roofing_enquiries';

// Optional Supabase integration if environment variables are provided
const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;

export async function submitEnquiry(formData: QuoteFormData): Promise<{ success: boolean; enquiry?: StoredEnquiry; error?: string }> {
  // Validate data
  const { isValid, errors } = validateQuoteForm(formData);
  if (!isValid) {
    const firstErrorMessage = Object.values(errors)[0] || "Invalid form submission";
    return { success: false, error: firstErrorMessage };
  }

  // Generate unique human-readable reference code
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const referenceNumber = `APX-${new Date().getFullYear()}-${randomSuffix}`;
  const nowIso = new Date().toISOString();

  let storageTarget: 'supabase' | 'local_demo_store' = 'local_demo_store';

  // Attempt Supabase submission if keys exist
  if (SUPABASE_URL && SUPABASE_ANON_KEY) {
    try {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/enquiries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({
          full_name: formData.fullName,
          phone: formData.phone,
          email: formData.email,
          property_type: formData.propertyType,
          service_needed: formData.serviceNeeded,
          message: formData.message,
          status: 'new',
          created_at: nowIso
        })
      });

      if (response.ok) {
        storageTarget = 'supabase';
      }
    } catch (err) {
      console.warn("Supabase network request failed; persisting to local demonstrator store.", err);
    }
  }

  // Persist locally so evaluator/client can immediately view and manage their submissions
  const enquiry: StoredEnquiry = {
    ...formData,
    id: `enq_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    referenceNumber,
    status: 'new',
    createdAt: nowIso,
    storageTarget
  };

  try {
    const existing = getStoredEnquiries();
    const updated = [enquiry, ...existing];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn("Local storage write error:", e);
  }

  // Dispatch a custom window event so any listeners (like the Enquiries Drawer) update live
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('apex:enquiry-submitted', { detail: enquiry }));
  }

  return {
    success: true,
    enquiry
  };
}

export function getStoredEnquiries(): StoredEnquiry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function deleteStoredEnquiry(id: string): StoredEnquiry[] {
  if (typeof window === 'undefined') return [];
  const list = getStoredEnquiries().filter(e => e.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent('apex:enquiry-updated', { detail: list }));
  return list;
}

export function clearAllEnquiries(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new CustomEvent('apex:enquiry-updated', { detail: [] }));
}
